
package whatmobile;

import java.awt.*;
import javax.swing.*;

public class Home extends javax.swing.JFrame {

    boolean a = false;
    public Home() {
        initComponents();
    }

    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        header = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        CloseButton = new javax.swing.JPanel();
        closeLabel = new javax.swing.JLabel();
        minimizeButton = new javax.swing.JPanel();
        minimizeLabel = new javax.swing.JLabel();
        buttonMaximum = new javax.swing.JPanel();
        maxmimumLabel = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        menu = new javax.swing.JPanel();
        menuIcons = new javax.swing.JPanel();
        lineMenu = new javax.swing.JPanel();
        menuPanel = new javax.swing.JPanel();
        iMenu = new javax.swing.JLabel();
        lineMobiles = new javax.swing.JPanel();
        mobilesPanel = new javax.swing.JPanel();
        iMobiles = new javax.swing.JLabel();
        lineNews = new javax.swing.JPanel();
        newsPanel = new javax.swing.JPanel();
        iNews = new javax.swing.JLabel();
        lineMail = new javax.swing.JPanel();
        mailPanel = new javax.swing.JPanel();
        iMail = new javax.swing.JLabel();
        lineShop = new javax.swing.JPanel();
        shopPanel = new javax.swing.JPanel();
        iShop = new javax.swing.JLabel();
        menuHide = new javax.swing.JPanel();
        lineMobiles2 = new javax.swing.JPanel();
        mobilesPanel2 = new javax.swing.JPanel();
        iMobiles1 = new javax.swing.JLabel();
        lineNews2 = new javax.swing.JPanel();
        lineMail2 = new javax.swing.JPanel();
        lineShop2 = new javax.swing.JPanel();
        newsPanel2 = new javax.swing.JPanel();
        iNews1 = new javax.swing.JLabel();
        mailPanel1 = new javax.swing.JPanel();
        iMail1 = new javax.swing.JLabel();
        shopPanel1 = new javax.swing.JPanel();
        iShop1 = new javax.swing.JLabel();
        menuPanel1 = new javax.swing.JPanel();
        iMenu1 = new javax.swing.JLabel();
        lineMenu1 = new javax.swing.JPanel();
        dashBoardView = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(800, 500));

        header.setBackground(new java.awt.Color(36, 87, 152));
        header.setLayout(new java.awt.BorderLayout());

        jPanel5.setBackground(new java.awt.Color(36, 87, 152));
        jPanel5.setMinimumSize(new java.awt.Dimension(170, 40));
        jPanel5.setPreferredSize(new java.awt.Dimension(170, 40));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        CloseButton.setBackground(new java.awt.Color(36, 87, 152));
        CloseButton.setLayout(new java.awt.BorderLayout());

        closeLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/icons8_multiply_48.png"))); // NOI18N
        closeLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                closeLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                closeLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                closeLabelMouseExited(evt);
            }
        });
        CloseButton.add(closeLabel, java.awt.BorderLayout.CENTER);

        jPanel5.add(CloseButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 0, 50, 50));

        minimizeButton.setBackground(new java.awt.Color(36, 87, 152));
        minimizeButton.setLayout(new java.awt.BorderLayout());

        minimizeLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/icons8_subtract_48.png"))); // NOI18N
        minimizeLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                minimizeLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                minimizeLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                minimizeLabelMouseExited(evt);
            }
        });
        minimizeButton.add(minimizeLabel, java.awt.BorderLayout.CENTER);

        jPanel5.add(minimizeButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 50, 50));

        buttonMaximum.setBackground(new java.awt.Color(36, 87, 152));
        buttonMaximum.setLayout(new java.awt.BorderLayout());

        maxmimumLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/icons8_full_screen_48.png"))); // NOI18N
        maxmimumLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                maxmimumLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                maxmimumLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                maxmimumLabelMouseExited(evt);
            }
        });
        buttonMaximum.add(maxmimumLabel, java.awt.BorderLayout.CENTER);

        jPanel5.add(buttonMaximum, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 0, 50, 50));

        header.add(jPanel5, java.awt.BorderLayout.LINE_END);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/11070823_798808190167734_5912407124608451387_n.png"))); // NOI18N
        header.add(jLabel1, java.awt.BorderLayout.CENTER);

        getContentPane().add(header, java.awt.BorderLayout.PAGE_START);

        menu.setBackground(new java.awt.Color(36, 87, 152));
        menu.setPreferredSize(new java.awt.Dimension(270, 400));
        menu.setLayout(new java.awt.BorderLayout());

        menuIcons.setBackground(new java.awt.Color(10, 36, 101));
        menuIcons.setPreferredSize(new java.awt.Dimension(60, 400));
        menuIcons.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lineMenu.setBackground(new java.awt.Color(10, 36, 101));
        lineMenu.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineMenuLayout = new javax.swing.GroupLayout(lineMenu);
        lineMenu.setLayout(lineMenuLayout);
        lineMenuLayout.setHorizontalGroup(
            lineMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        lineMenuLayout.setVerticalGroup(
            lineMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuIcons.add(lineMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 60, 5));

        menuPanel.setBackground(new java.awt.Color(10, 36, 101));
        menuPanel.setLayout(new java.awt.BorderLayout());

        iMenu.setBackground(new java.awt.Color(10, 36, 101));
        iMenu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/icons8_menu_48.png"))); // NOI18N
        iMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iMenuMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iMenuMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iMenuMouseExited(evt);
            }
        });
        menuPanel.add(iMenu, java.awt.BorderLayout.CENTER);

        menuIcons.add(menuPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 5, 60, 60));

        lineMobiles.setBackground(new java.awt.Color(10, 36, 101));
        lineMobiles.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineMobilesLayout = new javax.swing.GroupLayout(lineMobiles);
        lineMobiles.setLayout(lineMobilesLayout);
        lineMobilesLayout.setHorizontalGroup(
            lineMobilesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        lineMobilesLayout.setVerticalGroup(
            lineMobilesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuIcons.add(lineMobiles, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 65, 60, 5));

        mobilesPanel.setBackground(new java.awt.Color(10, 36, 101));
        mobilesPanel.setLayout(new java.awt.BorderLayout());

        iMobiles.setBackground(new java.awt.Color(10, 36, 101));
        iMobiles.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iMobiles.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/icons8_mobile_48.png"))); // NOI18N
        iMobiles.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iMobilesMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iMobilesMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iMobilesMouseExited(evt);
            }
        });
        mobilesPanel.add(iMobiles, java.awt.BorderLayout.CENTER);

        menuIcons.add(mobilesPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 60, 60));

        lineNews.setBackground(new java.awt.Color(10, 36, 101));
        lineNews.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineNewsLayout = new javax.swing.GroupLayout(lineNews);
        lineNews.setLayout(lineNewsLayout);
        lineNewsLayout.setHorizontalGroup(
            lineNewsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        lineNewsLayout.setVerticalGroup(
            lineNewsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuIcons.add(lineNews, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 60, 5));

        newsPanel.setBackground(new java.awt.Color(10, 36, 101));
        newsPanel.setLayout(new java.awt.BorderLayout());

        iNews.setBackground(new java.awt.Color(10, 36, 101));
        iNews.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iNews.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/icons8_news_48.png"))); // NOI18N
        iNews.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iNewsMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iNewsMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iNewsMouseExited(evt);
            }
        });
        newsPanel.add(iNews, java.awt.BorderLayout.CENTER);

        menuIcons.add(newsPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 135, 60, 60));

        lineMail.setBackground(new java.awt.Color(10, 36, 101));
        lineMail.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineMailLayout = new javax.swing.GroupLayout(lineMail);
        lineMail.setLayout(lineMailLayout);
        lineMailLayout.setHorizontalGroup(
            lineMailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        lineMailLayout.setVerticalGroup(
            lineMailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuIcons.add(lineMail, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 195, 60, 5));

        mailPanel.setBackground(new java.awt.Color(10, 36, 101));
        mailPanel.setLayout(new java.awt.BorderLayout());

        iMail.setBackground(new java.awt.Color(10, 36, 101));
        iMail.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iMail.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/icons8_mailbox_48.png"))); // NOI18N
        iMail.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iMailMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iMailMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iMailMouseExited(evt);
            }
        });
        mailPanel.add(iMail, java.awt.BorderLayout.CENTER);

        menuIcons.add(mailPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 60, 60));

        lineShop.setBackground(new java.awt.Color(10, 36, 101));
        lineShop.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineShopLayout = new javax.swing.GroupLayout(lineShop);
        lineShop.setLayout(lineShopLayout);
        lineShopLayout.setHorizontalGroup(
            lineShopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        lineShopLayout.setVerticalGroup(
            lineShopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuIcons.add(lineShop, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 260, 60, 5));

        shopPanel.setBackground(new java.awt.Color(10, 36, 101));
        shopPanel.setLayout(new java.awt.BorderLayout());

        iShop.setBackground(new java.awt.Color(10, 36, 101));
        iShop.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iShop.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/icons8_shop_48.png"))); // NOI18N
        iShop.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iShopMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iShopMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iShopMouseExited(evt);
            }
        });
        shopPanel.add(iShop, java.awt.BorderLayout.CENTER);

        menuIcons.add(shopPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 265, 60, 60));

        menu.add(menuIcons, java.awt.BorderLayout.LINE_START);

        menuHide.setBackground(new java.awt.Color(36, 87, 152));
        menuHide.setRequestFocusEnabled(false);
        menuHide.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lineMobiles2.setBackground(new java.awt.Color(10, 36, 101));
        lineMobiles2.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineMobiles2Layout = new javax.swing.GroupLayout(lineMobiles2);
        lineMobiles2.setLayout(lineMobiles2Layout);
        lineMobiles2Layout.setHorizontalGroup(
            lineMobiles2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 210, Short.MAX_VALUE)
        );
        lineMobiles2Layout.setVerticalGroup(
            lineMobiles2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuHide.add(lineMobiles2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 65, 210, 5));

        mobilesPanel2.setBackground(new java.awt.Color(10, 36, 101));
        mobilesPanel2.setLayout(new java.awt.BorderLayout());

        iMobiles1.setBackground(new java.awt.Color(0, 0, 0));
        iMobiles1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        iMobiles1.setForeground(new java.awt.Color(255, 255, 255));
        iMobiles1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iMobiles1.setText("Mobiles");
        iMobiles1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iMobiles1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iMobiles1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iMobiles1MouseExited(evt);
            }
        });
        mobilesPanel2.add(iMobiles1, java.awt.BorderLayout.CENTER);

        menuHide.add(mobilesPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 210, 60));

        lineNews2.setBackground(new java.awt.Color(10, 36, 101));
        lineNews2.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineNews2Layout = new javax.swing.GroupLayout(lineNews2);
        lineNews2.setLayout(lineNews2Layout);
        lineNews2Layout.setHorizontalGroup(
            lineNews2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 210, Short.MAX_VALUE)
        );
        lineNews2Layout.setVerticalGroup(
            lineNews2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuHide.add(lineNews2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 210, 5));

        lineMail2.setBackground(new java.awt.Color(10, 36, 101));
        lineMail2.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineMail2Layout = new javax.swing.GroupLayout(lineMail2);
        lineMail2.setLayout(lineMail2Layout);
        lineMail2Layout.setHorizontalGroup(
            lineMail2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 210, Short.MAX_VALUE)
        );
        lineMail2Layout.setVerticalGroup(
            lineMail2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuHide.add(lineMail2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 195, 210, 5));

        lineShop2.setBackground(new java.awt.Color(10, 36, 101));
        lineShop2.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineShop2Layout = new javax.swing.GroupLayout(lineShop2);
        lineShop2.setLayout(lineShop2Layout);
        lineShop2Layout.setHorizontalGroup(
            lineShop2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 210, Short.MAX_VALUE)
        );
        lineShop2Layout.setVerticalGroup(
            lineShop2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuHide.add(lineShop2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 260, 210, 5));

        newsPanel2.setBackground(new java.awt.Color(10, 36, 101));
        newsPanel2.setLayout(new java.awt.BorderLayout());

        iNews1.setBackground(new java.awt.Color(0, 0, 0));
        iNews1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        iNews1.setForeground(new java.awt.Color(255, 255, 255));
        iNews1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iNews1.setText("News");
        iNews1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iNews1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iNews1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iNews1MouseExited(evt);
            }
        });
        newsPanel2.add(iNews1, java.awt.BorderLayout.CENTER);

        menuHide.add(newsPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 135, 210, 60));

        mailPanel1.setBackground(new java.awt.Color(10, 36, 101));
        mailPanel1.setLayout(new java.awt.BorderLayout());

        iMail1.setBackground(new java.awt.Color(0, 0, 0));
        iMail1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        iMail1.setForeground(new java.awt.Color(255, 255, 255));
        iMail1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iMail1.setText("Contact Us");
        iMail1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iMail1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iMail1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iMail1MouseExited(evt);
            }
        });
        mailPanel1.add(iMail1, java.awt.BorderLayout.CENTER);

        menuHide.add(mailPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 210, 60));

        shopPanel1.setBackground(new java.awt.Color(10, 36, 101));
        shopPanel1.setLayout(new java.awt.BorderLayout());

        iShop1.setBackground(new java.awt.Color(0, 0, 0));
        iShop1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        iShop1.setForeground(new java.awt.Color(255, 255, 255));
        iShop1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iShop1.setText("Shopes");
        iShop1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iShop1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iShop1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iShop1MouseExited(evt);
            }
        });
        shopPanel1.add(iShop1, java.awt.BorderLayout.CENTER);

        menuHide.add(shopPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 265, 210, 60));

        menuPanel1.setBackground(new java.awt.Color(10, 36, 101));
        menuPanel1.setLayout(new java.awt.BorderLayout());

        iMenu1.setBackground(new java.awt.Color(10, 36, 101));
        iMenu1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iMenu1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iMenu1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iMenu1MouseExited(evt);
            }
        });
        menuPanel1.add(iMenu1, java.awt.BorderLayout.CENTER);

        menuHide.add(menuPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 5, 210, 60));

        lineMenu1.setBackground(new java.awt.Color(10, 36, 101));
        lineMenu1.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineMenu1Layout = new javax.swing.GroupLayout(lineMenu1);
        lineMenu1.setLayout(lineMenu1Layout);
        lineMenu1Layout.setHorizontalGroup(
            lineMenu1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 210, Short.MAX_VALUE)
        );
        lineMenu1Layout.setVerticalGroup(
            lineMenu1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuHide.add(lineMenu1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 210, 5));

        menu.add(menuHide, java.awt.BorderLayout.CENTER);

        getContentPane().add(menu, java.awt.BorderLayout.LINE_START);

        dashBoardView.setBackground(new java.awt.Color(51, 102, 255));

        javax.swing.GroupLayout dashBoardViewLayout = new javax.swing.GroupLayout(dashBoardView);
        dashBoardView.setLayout(dashBoardViewLayout);
        dashBoardViewLayout.setHorizontalGroup(
            dashBoardViewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 983, Short.MAX_VALUE)
        );
        dashBoardViewLayout.setVerticalGroup(
            dashBoardViewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 428, Short.MAX_VALUE)
        );

        getContentPane().add(dashBoardView, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 1253, 614);
    }// </editor-fold>//GEN-END:initComponents

    public void ChangeColor(JPanel hover, Color rand){
        hover.setBackground(rand);
    }
    public void changeimage(JLabel button, String resourcheimg){
        ImageIcon aimg = new ImageIcon(getClass().getResource(resourcheimg));
        button.setIcon(aimg);
    }
    public void hideshow(JLabel menushowhide,boolean dashboard, JLabel button){
        if (dashboard == true) {
            menushowhide.setPreferredSize(new Dimension(60, menushowhide.getHeight()));
            changeimage(button, "/WhatMobile.icons/icons8_left_48.png");
        }
        else{
            menushowhide.setPreferredSize(new Dimension(270, menushowhide.getHeight()));
            changeimage(button, "/WhatMobile.icons/icons8_menu_48.png");
        
        }
    }
        
    private void closeLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeLabelMouseClicked
        System.exit(0);
    }//GEN-LAST:event_closeLabelMouseClicked

    private void closeLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeLabelMouseEntered
        ChangeColor(CloseButton, new Color(216, 59, 1));
    }//GEN-LAST:event_closeLabelMouseEntered

    private void closeLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeLabelMouseExited
        ChangeColor(CloseButton, new Color(181, 64, 30));
    }//GEN-LAST:event_closeLabelMouseExited

    private void maxmimumLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_maxmimumLabelMouseEntered
        ChangeColor(buttonMaximum, new Color(0, 0, 255));
    }//GEN-LAST:event_maxmimumLabelMouseEntered

    private void maxmimumLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_maxmimumLabelMouseClicked
        if(this.getExtendedState()!= Home.MAXIMIZED_BOTH){
            this.setExtendedState(Home.MAXIMIZED_BOTH);
        }
        else{
            this.setExtendedState(Home.NORMAL);
        }
    }//GEN-LAST:event_maxmimumLabelMouseClicked

    private void maxmimumLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_maxmimumLabelMouseExited
        ChangeColor(buttonMaximum, new Color(36, 87, 152));
    }//GEN-LAST:event_maxmimumLabelMouseExited

    private void minimizeLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimizeLabelMouseEntered
        ChangeColor(buttonMaximum, new Color(0, 0, 255));
    }//GEN-LAST:event_minimizeLabelMouseEntered

    private void minimizeLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimizeLabelMouseClicked
        
    }//GEN-LAST:event_minimizeLabelMouseClicked

    private void minimizeLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimizeLabelMouseExited
        ChangeColor(buttonMaximum, new Color(36, 87, 152));
    }//GEN-LAST:event_minimizeLabelMouseExited

    private void iMenuMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMenuMouseEntered
        ChangeColor(lineMenu, new Color(247,78,104));
        ChangeColor(lineMenu1, new Color(247,78,104));
    }//GEN-LAST:event_iMenuMouseEntered

    private void iMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMenuMouseClicked
        mobilesPanel.setBackground(new Color(10, 36, 101));
        menuPanel.setBackground(new Color(36, 87, 152));
        mailPanel.setBackground(new Color(10, 36, 101));
        newsPanel.setBackground(new Color(10, 36, 101));
        shopPanel.setBackground(new Color(10, 36, 101));
        
        mobilesPanel2.setBackground(new Color(10, 36, 101));
        menuPanel1.setBackground(new Color(36, 87, 152));
        mailPanel1.setBackground(new Color(10, 36, 101));
        newsPanel2.setBackground(new Color(10, 36, 101));
        shopPanel1.setBackground(new Color(10, 36, 101));
        if (a == true) {
            hideshow(menu, a , iMenu);
            SwingUtilities.updateComponentTreeUI(this);
            a=false;
        }
        else
        {
        hideshow(menu , a ,iMenu);
        SwingUtilities.updateComponentTreeUI(this);
        a=true;
        }
    }//GEN-LAST:event_iMenuMouseClicked

    private void iMenuMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMenuMouseExited
        ChangeColor(lineMenu, new Color(36, 87, 152));
        ChangeColor(lineMenu1, new Color(36, 87, 152));
    }//GEN-LAST:event_iMenuMouseExited

    private void iMobilesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMobilesMouseEntered
        ChangeColor(lineMobiles, new Color(8,177,150));
        ChangeColor(lineMobiles2, new Color(8,177,150));
    }//GEN-LAST:event_iMobilesMouseEntered

    private void iMobilesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMobilesMouseClicked
        mobilesPanel.setBackground(new Color(36, 87, 152));
        menuPanel.setBackground(new Color(10, 36, 101));
        mailPanel.setBackground(new Color(10, 36, 101));
        newsPanel.setBackground(new Color(10, 36, 101));
        shopPanel.setBackground(new Color(10, 36, 101));
        mobilesPanel2.setBackground(new Color(36, 87, 152));
        menuPanel1.setBackground(new Color(10, 36, 101));
        mailPanel1.setBackground(new Color(10, 36, 101));
        newsPanel2.setBackground(new Color(10, 36, 101));
        shopPanel1.setBackground(new Color(10, 36, 101));
    }//GEN-LAST:event_iMobilesMouseClicked

    private void iMobilesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMobilesMouseExited
        ChangeColor(lineMobiles, new Color(36, 87, 152));
        ChangeColor(lineMobiles2, new Color(36, 87, 152));
    }//GEN-LAST:event_iMobilesMouseExited

    private void iNewsMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iNewsMouseEntered
        ChangeColor(lineNews, new Color(254, 215, 0));
        ChangeColor(lineNews2, new Color(254, 215, 0));
    }//GEN-LAST:event_iNewsMouseEntered

    private void iNewsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iNewsMouseClicked
        mobilesPanel.setBackground(new Color(10, 36, 101));
        menuPanel.setBackground(new Color(10, 36, 101));
        mailPanel.setBackground(new Color(10, 36, 101));
        newsPanel.setBackground(new Color(36, 87, 152));
        shopPanel.setBackground(new Color(10, 36, 101));
        
        mobilesPanel2.setBackground(new Color(10, 36, 101));
        menuPanel1.setBackground(new Color(10, 36, 101));
        mailPanel1.setBackground(new Color(10, 36, 101));
        newsPanel2.setBackground(new Color(36, 87, 152));
        shopPanel1.setBackground(new Color(10, 36, 101));
    }//GEN-LAST:event_iNewsMouseClicked

    private void iNewsMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iNewsMouseExited
        ChangeColor(lineNews, new Color(36, 87, 152));
        ChangeColor(lineNews2, new Color(36, 87, 152));
    }//GEN-LAST:event_iNewsMouseExited

    private void iMailMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMailMouseEntered
        ChangeColor(lineMail, new Color(255, 255, 255));
        ChangeColor(lineMail2, new Color(255, 255, 255));
    }//GEN-LAST:event_iMailMouseEntered

    private void iMailMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMailMouseClicked
        mobilesPanel.setBackground(new Color(10, 36, 101));
        menuPanel.setBackground(new Color(10, 36, 101));
        mailPanel.setBackground(new Color(36, 87, 152));
        newsPanel.setBackground(new Color(10, 36, 101));
        shopPanel.setBackground(new Color(10, 36, 101));
        
        mobilesPanel2.setBackground(new Color(10, 36, 101));
        menuPanel1.setBackground(new Color(10, 36, 101));
        mailPanel1.setBackground(new Color(36, 87, 152));
        newsPanel2.setBackground(new Color(10, 36, 101));
        shopPanel1.setBackground(new Color(10, 36, 101));
    }//GEN-LAST:event_iMailMouseClicked

    private void iMailMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMailMouseExited
        ChangeColor(lineMail, new Color(36, 87, 152));
        ChangeColor(lineMail2, new Color(36, 87, 152));
    }//GEN-LAST:event_iMailMouseExited

    private void iShopMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iShopMouseEntered
        ChangeColor(lineShop, new Color(0, 255, 255));
        ChangeColor(lineShop2, new Color(0, 255, 255));
    }//GEN-LAST:event_iShopMouseEntered

    private void iShopMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iShopMouseClicked
        mobilesPanel.setBackground(new Color(10, 36, 101));
        menuPanel.setBackground(new Color(10, 36, 101));
        mailPanel.setBackground(new Color(10, 36, 101));
        newsPanel.setBackground(new Color(10, 36, 101));
        shopPanel.setBackground(new Color(36, 87, 152));
        
        mobilesPanel2.setBackground(new Color(10, 36, 101));
        menuPanel1.setBackground(new Color(10, 36, 101));
        mailPanel1.setBackground(new Color(10, 36, 101));
        newsPanel2.setBackground(new Color(10, 36, 101));
        shopPanel1.setBackground(new Color(36, 87, 152));
    }//GEN-LAST:event_iShopMouseClicked

    private void iShopMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iShopMouseExited
        ChangeColor(lineShop, new Color(36, 87, 152));
        ChangeColor(lineShop2, new Color(36, 87, 152));
    }//GEN-LAST:event_iShopMouseExited

    private void iNews1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iNews1MouseExited
        ChangeColor(lineNews, new Color(36, 87, 152));
        ChangeColor(lineNews2, new Color(36, 87, 152));
    }//GEN-LAST:event_iNews1MouseExited

    private void iNews1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iNews1MouseEntered
         ChangeColor(lineNews, new Color(254, 215, 0));
          ChangeColor(lineNews2, new Color(254, 215, 0));
    }//GEN-LAST:event_iNews1MouseEntered

    private void iNews1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iNews1MouseClicked
        mobilesPanel.setBackground(new Color(10, 36, 101));
        menuPanel.setBackground(new Color(10, 36, 101));
        mailPanel.setBackground(new Color(10, 36, 101));
        newsPanel.setBackground(new Color(36, 87, 152));
        shopPanel.setBackground(new Color(10, 36, 101));
        
        mobilesPanel2.setBackground(new Color(10, 36, 101));
        menuPanel1.setBackground(new Color(10, 36, 101));
        mailPanel1.setBackground(new Color(10, 36, 101));
        newsPanel2.setBackground(new Color(36, 87, 152));
        shopPanel1.setBackground(new Color(10, 36, 101));
    }//GEN-LAST:event_iNews1MouseClicked

    private void iMobiles1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMobiles1MouseClicked
        mobilesPanel.setBackground(new Color(36, 87, 152));
        menuPanel.setBackground(new Color(10, 36, 101));
        mailPanel.setBackground(new Color(10, 36, 101));
        newsPanel.setBackground(new Color(10, 36, 101));
        shopPanel.setBackground(new Color(10, 36, 101));
        
        mobilesPanel2.setBackground(new Color(36, 87, 152));
        menuPanel1.setBackground(new Color(10, 36, 101));
        mailPanel1.setBackground(new Color(10, 36, 101));
        newsPanel2.setBackground(new Color(10, 36, 101));
        shopPanel1.setBackground(new Color(10, 36, 101));
    }//GEN-LAST:event_iMobiles1MouseClicked

    private void iMobiles1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMobiles1MouseEntered
        ChangeColor(lineMobiles, new Color(8,177,150));
        ChangeColor(lineMobiles2, new Color(8,177,150));
    }//GEN-LAST:event_iMobiles1MouseEntered

    private void iMobiles1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMobiles1MouseExited
        ChangeColor(lineMobiles, new Color(36, 87, 152));
        ChangeColor(lineMobiles2, new Color(36, 87, 152));        
    }//GEN-LAST:event_iMobiles1MouseExited

    private void iMail1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMail1MouseClicked
        mobilesPanel.setBackground(new Color(10, 36, 101));
        menuPanel.setBackground(new Color(10, 36, 101));
        mailPanel.setBackground(new Color(36, 87, 152));
        newsPanel.setBackground(new Color(10, 36, 101));
        shopPanel.setBackground(new Color(10, 36, 101));
        
        mobilesPanel2.setBackground(new Color(10, 36, 101));
        menuPanel1.setBackground(new Color(10, 36, 101));
        mailPanel1.setBackground(new Color(36, 87, 152));
        newsPanel2.setBackground(new Color(10, 36, 101));
        shopPanel1.setBackground(new Color(10, 36, 101));
    }//GEN-LAST:event_iMail1MouseClicked

    private void iMail1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMail1MouseEntered
        ChangeColor(lineMail, new Color(255, 255, 255));
        ChangeColor(lineMail2, new Color(255, 255, 255));
        
    }//GEN-LAST:event_iMail1MouseEntered

    private void iMail1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMail1MouseExited
        ChangeColor(lineMail, new Color(36, 87, 152));
        ChangeColor(lineMail2, new Color(36, 87, 152));
    }//GEN-LAST:event_iMail1MouseExited

    private void iShop1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iShop1MouseClicked
        mobilesPanel.setBackground(new Color(10, 36, 101));
        menuPanel.setBackground(new Color(10, 36, 101));
        mailPanel.setBackground(new Color(10, 36, 101));
        newsPanel.setBackground(new Color(10, 36, 101));
        shopPanel.setBackground(new Color(36, 87, 152));
        
        mobilesPanel2.setBackground(new Color(10, 36, 101));
        menuPanel1.setBackground(new Color(10, 36, 101));
        mailPanel1.setBackground(new Color(10, 36, 101));
        newsPanel2.setBackground(new Color(10, 36, 101));
        shopPanel1.setBackground(new Color(36, 87, 152));
    }//GEN-LAST:event_iShop1MouseClicked

    private void iShop1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iShop1MouseEntered
        ChangeColor(lineShop, new Color(0, 255, 255));
        ChangeColor(lineShop2, new Color(0, 255, 255));
    }//GEN-LAST:event_iShop1MouseEntered

    private void iShop1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iShop1MouseExited
        ChangeColor(lineShop, new Color(36, 87, 152));
        ChangeColor(lineShop2, new Color(36, 87, 152));
    }//GEN-LAST:event_iShop1MouseExited

    private void iMenu1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMenu1MouseExited
        ChangeColor(lineMenu, new Color(36, 87, 152));
        ChangeColor(lineMenu1, new Color(36, 87, 152));
    }//GEN-LAST:event_iMenu1MouseExited

    private void iMenu1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMenu1MouseEntered
        ChangeColor(lineMenu, new Color(247,78,104));
        ChangeColor(lineMenu1, new Color(247,78,104));
    }//GEN-LAST:event_iMenu1MouseEntered

    private void iMenu1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMenu1MouseClicked
        mobilesPanel.setBackground(new Color(10, 36, 101));
       // menuPanel.setBackground(new Color(36, 87, 152));
        mailPanel.setBackground(new Color(10, 36, 101));
        newsPanel.setBackground(new Color(10, 36, 101));
        shopPanel.setBackground(new Color(10, 36, 101));
        
    }//GEN-LAST:event_iMenu1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Home().setVisible(true);
                
            }
             
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel CloseButton;
    private javax.swing.JPanel buttonMaximum;
    private javax.swing.JLabel closeLabel;
    private javax.swing.JPanel dashBoardView;
    private javax.swing.JPanel header;
    private javax.swing.JLabel iMail;
    private javax.swing.JLabel iMail1;
    private javax.swing.JLabel iMenu;
    private javax.swing.JLabel iMenu1;
    private javax.swing.JLabel iMobiles;
    private javax.swing.JLabel iMobiles1;
    private javax.swing.JLabel iNews;
    private javax.swing.JLabel iNews1;
    private javax.swing.JLabel iShop;
    private javax.swing.JLabel iShop1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel lineMail;
    private javax.swing.JPanel lineMail2;
    private javax.swing.JPanel lineMenu;
    private javax.swing.JPanel lineMenu1;
    private javax.swing.JPanel lineMobiles;
    private javax.swing.JPanel lineMobiles2;
    private javax.swing.JPanel lineNews;
    private javax.swing.JPanel lineNews2;
    private javax.swing.JPanel lineShop;
    private javax.swing.JPanel lineShop2;
    private javax.swing.JPanel mailPanel;
    private javax.swing.JPanel mailPanel1;
    private javax.swing.JLabel maxmimumLabel;
    private javax.swing.JPanel menu;
    private javax.swing.JPanel menuHide;
    private javax.swing.JPanel menuIcons;
    private javax.swing.JPanel menuPanel;
    private javax.swing.JPanel menuPanel1;
    private javax.swing.JPanel minimizeButton;
    private javax.swing.JLabel minimizeLabel;
    private javax.swing.JPanel mobilesPanel;
    private javax.swing.JPanel mobilesPanel2;
    private javax.swing.JPanel newsPanel;
    private javax.swing.JPanel newsPanel2;
    private javax.swing.JPanel shopPanel;
    private javax.swing.JPanel shopPanel1;
    // End of variables declaration//GEN-END:variables

    private void iMenuMouseEntered(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
