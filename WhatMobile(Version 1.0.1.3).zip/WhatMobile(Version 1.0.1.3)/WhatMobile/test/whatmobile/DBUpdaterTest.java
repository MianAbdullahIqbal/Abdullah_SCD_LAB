/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package whatmobile;

import javax.swing.table.DefaultTableModel;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author abdul
 */
public class DBUpdaterTest {
    
    public DBUpdaterTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getDataBuild method, of class DBUpdater.
     */
    @Test
    public void testGetDataBuild() {
        System.out.println("getDataBuild");
        String Name = "";
        DBUpdater instance = new DBUpdater();
        DefaultTableModel expResult = null;
        DefaultTableModel result = instance.getDataBuild(Name);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getDataFrequency method, of class DBUpdater.
     */
    @Test
    public void testGetDataFrequency() {
        System.out.println("getDataFrequency");
        String Name = "";
        DBUpdater instance = new DBUpdater();
        DefaultTableModel expResult = null;
        DefaultTableModel result = instance.getDataFrequency(Name);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getDataProcessor method, of class DBUpdater.
     */
    @Test
    public void testGetDataProcessor() {
        System.out.println("getDataProcessor");
        String Name = "";
        DBUpdater instance = new DBUpdater();
        DefaultTableModel expResult = null;
        DefaultTableModel result = instance.getDataProcessor(Name);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getDataMemory method, of class DBUpdater.
     */
    @Test
    public void testGetDataMemory() {
        System.out.println("getDataMemory");
        String Name = "";
        DBUpdater instance = new DBUpdater();
        DefaultTableModel expResult = null;
        DefaultTableModel result = instance.getDataMemory(Name);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDataDisplay method, of class DBUpdater.
     */
    @Test
    public void testGetDataDisplay() {
        System.out.println("getDataDisplay");
        String Name = "";
        DBUpdater instance = new DBUpdater();
        DefaultTableModel expResult = null;
        DefaultTableModel result = instance.getDataDisplay(Name);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getDataCamera method, of class DBUpdater.
     */
    @Test
    public void testGetDataCamera() {
        System.out.println("getDataCamera");
        String Name = "";
        DBUpdater instance = new DBUpdater();
        DefaultTableModel expResult = null;
        DefaultTableModel result = instance.getDataCamera(Name);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getDataConnectivity method, of class DBUpdater.
     */
    @Test
    public void testGetDataConnectivity() {
        System.out.println("getDataConnectivity");
        String Name = "";
        DBUpdater instance = new DBUpdater();
        DefaultTableModel expResult = null;
        DefaultTableModel result = instance.getDataConnectivity(Name);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getDataFeatures method, of class DBUpdater.
     */
    @Test
    public void testGetDataFeatures() {
        System.out.println("getDataFeatures");
        String Name = "";
        DBUpdater instance = new DBUpdater();
        DefaultTableModel expResult = null;
        DefaultTableModel result = instance.getDataFeatures(Name);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getDataBattery method, of class DBUpdater.
     */
    @Test
    public void testGetDataBattery() {
        System.out.println("getDataBattery");
        String Name = "";
        DBUpdater instance = new DBUpdater();
        DefaultTableModel expResult = null;
        DefaultTableModel result = instance.getDataBattery(Name);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getDataPrice method, of class DBUpdater.
     */
    @Test
    public void testGetDataPrice() {
        System.out.println("getDataPrice");
        String Name = "";
        DBUpdater instance = new DBUpdater();
        DefaultTableModel expResult = null;
        DefaultTableModel result = instance.getDataPrice(Name);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getDataRatings method, of class DBUpdater.
     */
    @Test
    public void testGetDataRatings() {
        System.out.println("getDataRatings");
        String Name = "";
        DBUpdater instance = new DBUpdater();
        DefaultTableModel expResult = null;
        DefaultTableModel result = instance.getDataRatings(Name);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
