/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package whatmobile;

import java.awt.*;
import java.io.File;
import java.io.FileOutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class MobileDetails extends javax.swing.JFrame {

    /**
     * Creates new form MobileDetails
     */
    //connection
    public MobileDetails() {
        initComponents();

    }

    String mName;
    String conString = "jdbc:mysql://localhost:3306/what_mobile";
    String username = "root";
    String password = "";
    public MobileDetails(String Name) {

        initComponents();
        mobileNameLabel.setText(Name);
        mName = mobileNameLabel.getText();
        
    }

    private void retrieve() {
        DefaultTableModel Builddm = new DBUpdater().getDataBuild(mName);
        DefaultTableModel Frequencydm = new DBUpdater().getDataFrequency(mName);
        DefaultTableModel Processordm = new DBUpdater().getDataProcessor(mName);
        DefaultTableModel Displaydm = new DBUpdater().getDataDisplay(mName);
        DefaultTableModel Memorydm = new DBUpdater().getDataMemory(mName);
        DefaultTableModel Cameradm = new DBUpdater().getDataCamera(mName);
        DefaultTableModel Connectivitydm = new DBUpdater().getDataConnectivity(mName);
        DefaultTableModel Featuresdm = new DBUpdater().getDataFeatures(mName);
        DefaultTableModel Batterydm = new DBUpdater().getDataBattery(mName);
        DefaultTableModel Pricedm = new DBUpdater().getDataPrice(mName);
        DefaultTableModel Ratingsdm = new DBUpdater().getDataRatings(mName);

        BuildTable.setModel(Builddm);
        FrequencyTable.setModel(Frequencydm);
        ProcessorTable.setModel(Processordm);
        DisplayTable.setModel(Displaydm);
        MemoryTable.setModel(Memorydm);
        CameraTable.setModel(Cameradm);
        ConnectivityTable.setModel(Connectivitydm);
        FeaturesTable.setModel(Featuresdm);
        BatteryTable.setModel(Batterydm);
        PriceTable.setModel(Pricedm);
        RatingsTable.setModel(Ratingsdm);
    }

    public void ChangeColor(JPanel hover, Color rand) {
        hover.setBackground(rand);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        header = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        backPanel = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        mobileNameLabel = new javax.swing.JLabel();
        retrieve = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        picLabel = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel13 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        BuildTable = new javax.swing.JTable();
        jPanel8 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        FrequencyTable = new javax.swing.JTable();
        jPanel12 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        ProcessorTable = new javax.swing.JTable();
        jPanel18 = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jPanel20 = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        DisplayTable = new javax.swing.JTable();
        jPanel22 = new javax.swing.JPanel();
        jPanel23 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel24 = new javax.swing.JPanel();
        jPanel25 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        MemoryTable = new javax.swing.JTable();
        jPanel74 = new javax.swing.JPanel();
        jPanel75 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jPanel76 = new javax.swing.JPanel();
        jPanel77 = new javax.swing.JPanel();
        jScrollPane20 = new javax.swing.JScrollPane();
        CameraTable = new javax.swing.JTable();
        jPanel78 = new javax.swing.JPanel();
        jPanel79 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jPanel80 = new javax.swing.JPanel();
        jPanel81 = new javax.swing.JPanel();
        jScrollPane21 = new javax.swing.JScrollPane();
        ConnectivityTable = new javax.swing.JTable();
        jPanel26 = new javax.swing.JPanel();
        jPanel27 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jPanel28 = new javax.swing.JPanel();
        jPanel29 = new javax.swing.JPanel();
        jScrollPane8 = new javax.swing.JScrollPane();
        FeaturesTable = new javax.swing.JTable();
        jPanel30 = new javax.swing.JPanel();
        jPanel31 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jPanel32 = new javax.swing.JPanel();
        jPanel33 = new javax.swing.JPanel();
        jScrollPane9 = new javax.swing.JScrollPane();
        BatteryTable = new javax.swing.JTable();
        jPanel82 = new javax.swing.JPanel();
        jPanel83 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jPanel84 = new javax.swing.JPanel();
        jPanel85 = new javax.swing.JPanel();
        jScrollPane22 = new javax.swing.JScrollPane();
        PriceTable = new javax.swing.JTable();
        jPanel86 = new javax.swing.JPanel();
        jPanel87 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jPanel88 = new javax.swing.JPanel();
        jPanel89 = new javax.swing.JPanel();
        jScrollPane23 = new javax.swing.JScrollPane();
        RatingsTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        header.setBackground(new java.awt.Color(36, 87, 152));
        header.setPreferredSize(new java.awt.Dimension(999, 150));
        header.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/11070823_798808190167734_5912407124608451387_n.png"))); // NOI18N
        header.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 150));

        getContentPane().add(header, java.awt.BorderLayout.PAGE_START);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new java.awt.BorderLayout());

        jPanel2.setPreferredSize(new java.awt.Dimension(100, 400));
        jPanel2.setLayout(new java.awt.BorderLayout());

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setPreferredSize(new java.awt.Dimension(150, 100));
        jPanel3.setLayout(new java.awt.BorderLayout());

        backPanel.setBackground(new java.awt.Color(204, 204, 255));
        backPanel.setPreferredSize(new java.awt.Dimension(800, 100));
        backPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                backPanelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                backPanelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                backPanelMouseExited(evt);
            }
        });
        backPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/icons8_back_arrow_64.png"))); // NOI18N
        backPanel.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 150, 100));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Back");
        backPanel.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 24, 80, 50));

        jPanel3.add(backPanel, java.awt.BorderLayout.PAGE_START);

        jPanel2.add(jPanel3, java.awt.BorderLayout.LINE_START);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setPreferredSize(new java.awt.Dimension(450, 100));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        mobileNameLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        mobileNameLabel.setForeground(new java.awt.Color(51, 0, 255));
        jPanel4.add(mobileNameLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 160, 390, 70));

        retrieve.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        retrieve.setText("G e t  D e t a i l s");
        retrieve.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                retrieveMouseClicked(evt);
            }
        });
        jPanel4.add(retrieve, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 320, 310, 40));

        jPanel2.add(jPanel4, java.awt.BorderLayout.LINE_END);

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setLayout(new java.awt.BorderLayout());

        picLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel6.add(picLabel, java.awt.BorderLayout.CENTER);

        jPanel2.add(jPanel6, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel2, java.awt.BorderLayout.PAGE_START);

        jPanel13.setLayout(new java.awt.BorderLayout());

        jPanel14.setBackground(new java.awt.Color(51, 102, 255));
        jPanel14.setPreferredSize(new java.awt.Dimension(100, 30));
        jPanel14.setLayout(new java.awt.BorderLayout());

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Build");
        jPanel14.add(jLabel5, java.awt.BorderLayout.CENTER);

        jPanel13.add(jPanel14, java.awt.BorderLayout.PAGE_START);

        jPanel5.setLayout(new java.awt.BorderLayout());

        jPanel7.setPreferredSize(new java.awt.Dimension(100, 50));
        jPanel7.setLayout(new java.awt.BorderLayout());

        jScrollPane3.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane3.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        BuildTable.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        BuildTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "null", "null"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        BuildTable.setPreferredSize(new java.awt.Dimension(450, 35));
        BuildTable.setRowHeight(23);
        jScrollPane3.setViewportView(BuildTable);

        jPanel7.add(jScrollPane3, java.awt.BorderLayout.CENTER);

        jPanel5.add(jPanel7, java.awt.BorderLayout.PAGE_START);

        jPanel8.setLayout(new java.awt.BorderLayout());

        jPanel9.setBackground(new java.awt.Color(51, 102, 255));
        jPanel9.setPreferredSize(new java.awt.Dimension(100, 30));
        jPanel9.setLayout(new java.awt.BorderLayout());

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Frequency");
        jPanel9.add(jLabel3, java.awt.BorderLayout.CENTER);

        jPanel8.add(jPanel9, java.awt.BorderLayout.PAGE_START);

        jPanel10.setLayout(new java.awt.BorderLayout());

        jPanel11.setPreferredSize(new java.awt.Dimension(100, 50));
        jPanel11.setLayout(new java.awt.BorderLayout());

        jScrollPane4.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane4.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        FrequencyTable.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        FrequencyTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        FrequencyTable.setPreferredSize(new java.awt.Dimension(225, 35));
        FrequencyTable.setRowHeight(23);
        jScrollPane4.setViewportView(FrequencyTable);

        jPanel11.add(jScrollPane4, java.awt.BorderLayout.CENTER);

        jPanel10.add(jPanel11, java.awt.BorderLayout.PAGE_START);

        jPanel12.setLayout(new java.awt.BorderLayout());

        jPanel15.setBackground(new java.awt.Color(51, 102, 255));
        jPanel15.setPreferredSize(new java.awt.Dimension(100, 30));
        jPanel15.setLayout(new java.awt.BorderLayout());

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Processor");
        jPanel15.add(jLabel6, java.awt.BorderLayout.CENTER);

        jPanel12.add(jPanel15, java.awt.BorderLayout.PAGE_START);

        jPanel16.setLayout(new java.awt.BorderLayout());

        jPanel17.setPreferredSize(new java.awt.Dimension(100, 50));
        jPanel17.setLayout(new java.awt.BorderLayout());

        jScrollPane5.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane5.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        ProcessorTable.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        ProcessorTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        ProcessorTable.setPreferredSize(new java.awt.Dimension(225, 35));
        ProcessorTable.setRowHeight(23);
        jScrollPane5.setViewportView(ProcessorTable);

        jPanel17.add(jScrollPane5, java.awt.BorderLayout.CENTER);

        jPanel16.add(jPanel17, java.awt.BorderLayout.PAGE_START);

        jPanel18.setLayout(new java.awt.BorderLayout());

        jPanel19.setBackground(new java.awt.Color(51, 102, 255));
        jPanel19.setPreferredSize(new java.awt.Dimension(100, 30));
        jPanel19.setLayout(new java.awt.BorderLayout());

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Display");
        jPanel19.add(jLabel7, java.awt.BorderLayout.CENTER);

        jPanel18.add(jPanel19, java.awt.BorderLayout.PAGE_START);

        jPanel20.setLayout(new java.awt.BorderLayout());

        jPanel21.setPreferredSize(new java.awt.Dimension(100, 50));
        jPanel21.setLayout(new java.awt.BorderLayout());

        jScrollPane6.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane6.setToolTipText("");
        jScrollPane6.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        DisplayTable.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        DisplayTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        DisplayTable.setPreferredSize(new java.awt.Dimension(225, 35));
        DisplayTable.setRowHeight(23);
        jScrollPane6.setViewportView(DisplayTable);

        jPanel21.add(jScrollPane6, java.awt.BorderLayout.CENTER);

        jPanel20.add(jPanel21, java.awt.BorderLayout.PAGE_START);

        jPanel22.setLayout(new java.awt.BorderLayout());

        jPanel23.setBackground(new java.awt.Color(51, 102, 255));
        jPanel23.setPreferredSize(new java.awt.Dimension(100, 30));
        jPanel23.setLayout(new java.awt.BorderLayout());

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Memory");
        jPanel23.add(jLabel8, java.awt.BorderLayout.CENTER);

        jPanel22.add(jPanel23, java.awt.BorderLayout.PAGE_START);

        jPanel24.setLayout(new java.awt.BorderLayout());

        jPanel25.setPreferredSize(new java.awt.Dimension(100, 50));
        jPanel25.setLayout(new java.awt.BorderLayout());

        jScrollPane7.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane7.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        MemoryTable.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        MemoryTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null}
            },
            new String [] {
                "Title 1", "Title 2"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        MemoryTable.setPreferredSize(new java.awt.Dimension(150, 35));
        MemoryTable.setRowHeight(23);
        jScrollPane7.setViewportView(MemoryTable);

        jPanel25.add(jScrollPane7, java.awt.BorderLayout.CENTER);

        jPanel24.add(jPanel25, java.awt.BorderLayout.PAGE_START);

        jPanel74.setLayout(new java.awt.BorderLayout());

        jPanel75.setBackground(new java.awt.Color(51, 102, 255));
        jPanel75.setPreferredSize(new java.awt.Dimension(100, 30));
        jPanel75.setLayout(new java.awt.BorderLayout());

        jLabel21.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel21.setText("Camera");
        jPanel75.add(jLabel21, java.awt.BorderLayout.CENTER);

        jPanel74.add(jPanel75, java.awt.BorderLayout.PAGE_START);

        jPanel76.setLayout(new java.awt.BorderLayout());

        jPanel77.setPreferredSize(new java.awt.Dimension(100, 50));
        jPanel77.setLayout(new java.awt.BorderLayout());

        jScrollPane20.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane20.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        CameraTable.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        CameraTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        CameraTable.setPreferredSize(new java.awt.Dimension(225, 35));
        CameraTable.setRowHeight(23);
        jScrollPane20.setViewportView(CameraTable);

        jPanel77.add(jScrollPane20, java.awt.BorderLayout.CENTER);

        jPanel76.add(jPanel77, java.awt.BorderLayout.PAGE_START);

        jPanel78.setLayout(new java.awt.BorderLayout());

        jPanel79.setBackground(new java.awt.Color(51, 102, 255));
        jPanel79.setPreferredSize(new java.awt.Dimension(100, 30));
        jPanel79.setLayout(new java.awt.BorderLayout());

        jLabel22.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel22.setText("Connectivity");
        jPanel79.add(jLabel22, java.awt.BorderLayout.CENTER);

        jPanel78.add(jPanel79, java.awt.BorderLayout.PAGE_START);

        jPanel80.setLayout(new java.awt.BorderLayout());

        jPanel81.setPreferredSize(new java.awt.Dimension(100, 50));
        jPanel81.setLayout(new java.awt.BorderLayout());

        jScrollPane21.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane21.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        ConnectivityTable.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        ConnectivityTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "null", "null", "null"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        ConnectivityTable.setPreferredSize(new java.awt.Dimension(525, 35));
        ConnectivityTable.setRowHeight(23);
        jScrollPane21.setViewportView(ConnectivityTable);

        jPanel81.add(jScrollPane21, java.awt.BorderLayout.CENTER);

        jPanel80.add(jPanel81, java.awt.BorderLayout.PAGE_START);

        jPanel26.setLayout(new java.awt.BorderLayout());

        jPanel27.setBackground(new java.awt.Color(51, 102, 255));
        jPanel27.setPreferredSize(new java.awt.Dimension(100, 30));
        jPanel27.setLayout(new java.awt.BorderLayout());

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Features");
        jPanel27.add(jLabel9, java.awt.BorderLayout.CENTER);

        jPanel26.add(jPanel27, java.awt.BorderLayout.PAGE_START);

        jPanel28.setLayout(new java.awt.BorderLayout());

        jPanel29.setPreferredSize(new java.awt.Dimension(100, 50));
        jPanel29.setLayout(new java.awt.BorderLayout());

        jScrollPane8.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane8.setToolTipText("");
        jScrollPane8.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        FeaturesTable.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        FeaturesTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "null", "null", "null"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        FeaturesTable.setPreferredSize(new java.awt.Dimension(525, 35));
        FeaturesTable.setRowHeight(23);
        jScrollPane8.setViewportView(FeaturesTable);

        jPanel29.add(jScrollPane8, java.awt.BorderLayout.CENTER);

        jPanel28.add(jPanel29, java.awt.BorderLayout.PAGE_START);

        jPanel30.setLayout(new java.awt.BorderLayout());

        jPanel31.setBackground(new java.awt.Color(51, 102, 255));
        jPanel31.setPreferredSize(new java.awt.Dimension(100, 30));
        jPanel31.setLayout(new java.awt.BorderLayout());

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Battery");
        jPanel31.add(jLabel10, java.awt.BorderLayout.CENTER);

        jPanel30.add(jPanel31, java.awt.BorderLayout.PAGE_START);

        jPanel32.setLayout(new java.awt.BorderLayout());

        jPanel33.setPreferredSize(new java.awt.Dimension(100, 50));
        jPanel33.setLayout(new java.awt.BorderLayout());

        jScrollPane9.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane9.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        BatteryTable.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        BatteryTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null}
            },
            new String [] {
                "Title 1"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        BatteryTable.setPreferredSize(new java.awt.Dimension(75, 35));
        BatteryTable.setRowHeight(23);
        jScrollPane9.setViewportView(BatteryTable);

        jPanel33.add(jScrollPane9, java.awt.BorderLayout.CENTER);

        jPanel32.add(jPanel33, java.awt.BorderLayout.PAGE_START);

        jPanel82.setLayout(new java.awt.BorderLayout());

        jPanel83.setBackground(new java.awt.Color(51, 102, 255));
        jPanel83.setPreferredSize(new java.awt.Dimension(100, 30));
        jPanel83.setLayout(new java.awt.BorderLayout());

        jLabel23.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel23.setText("Price");
        jPanel83.add(jLabel23, java.awt.BorderLayout.CENTER);

        jPanel82.add(jPanel83, java.awt.BorderLayout.PAGE_START);

        jPanel84.setLayout(new java.awt.BorderLayout());

        jPanel85.setPreferredSize(new java.awt.Dimension(100, 50));
        jPanel85.setLayout(new java.awt.BorderLayout());

        jScrollPane22.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane22.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        PriceTable.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        PriceTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null}
            },
            new String [] {
                "Title 1"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        PriceTable.setPreferredSize(new java.awt.Dimension(75, 35));
        PriceTable.setRowHeight(23);
        jScrollPane22.setViewportView(PriceTable);

        jPanel85.add(jScrollPane22, java.awt.BorderLayout.CENTER);

        jPanel84.add(jPanel85, java.awt.BorderLayout.PAGE_START);

        jPanel86.setLayout(new java.awt.BorderLayout());

        jPanel87.setBackground(new java.awt.Color(51, 102, 255));
        jPanel87.setPreferredSize(new java.awt.Dimension(100, 30));
        jPanel87.setLayout(new java.awt.BorderLayout());

        jLabel24.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel24.setText("Ratings");
        jPanel87.add(jLabel24, java.awt.BorderLayout.CENTER);

        jPanel86.add(jPanel87, java.awt.BorderLayout.PAGE_START);

        jPanel88.setLayout(new java.awt.BorderLayout());

        jPanel89.setPreferredSize(new java.awt.Dimension(100, 50));
        jPanel89.setLayout(new java.awt.BorderLayout());

        jScrollPane23.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane23.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        RatingsTable.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        RatingsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null}
            },
            new String [] {
                "Title 1"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        RatingsTable.setPreferredSize(new java.awt.Dimension(75, 35));
        RatingsTable.setRowHeight(23);
        jScrollPane23.setViewportView(RatingsTable);

        jPanel89.add(jScrollPane23, java.awt.BorderLayout.CENTER);

        jPanel88.add(jPanel89, java.awt.BorderLayout.PAGE_START);

        jPanel86.add(jPanel88, java.awt.BorderLayout.CENTER);

        jPanel84.add(jPanel86, java.awt.BorderLayout.CENTER);

        jPanel82.add(jPanel84, java.awt.BorderLayout.CENTER);

        jPanel32.add(jPanel82, java.awt.BorderLayout.CENTER);

        jPanel30.add(jPanel32, java.awt.BorderLayout.CENTER);

        jPanel28.add(jPanel30, java.awt.BorderLayout.CENTER);

        jPanel26.add(jPanel28, java.awt.BorderLayout.CENTER);

        jPanel80.add(jPanel26, java.awt.BorderLayout.CENTER);

        jPanel78.add(jPanel80, java.awt.BorderLayout.CENTER);

        jPanel76.add(jPanel78, java.awt.BorderLayout.CENTER);

        jPanel74.add(jPanel76, java.awt.BorderLayout.CENTER);

        jPanel24.add(jPanel74, java.awt.BorderLayout.CENTER);

        jPanel22.add(jPanel24, java.awt.BorderLayout.CENTER);

        jPanel20.add(jPanel22, java.awt.BorderLayout.CENTER);

        jPanel18.add(jPanel20, java.awt.BorderLayout.CENTER);

        jPanel16.add(jPanel18, java.awt.BorderLayout.CENTER);

        jPanel12.add(jPanel16, java.awt.BorderLayout.CENTER);

        jPanel10.add(jPanel12, java.awt.BorderLayout.CENTER);

        jPanel8.add(jPanel10, java.awt.BorderLayout.CENTER);

        jPanel5.add(jPanel8, java.awt.BorderLayout.CENTER);

        jPanel13.add(jPanel5, java.awt.BorderLayout.CENTER);

        jScrollPane2.setViewportView(jPanel13);

        jPanel1.add(jScrollPane2, java.awt.BorderLayout.CENTER);

        jScrollPane1.setViewportView(jPanel1);

        getContentPane().add(jScrollPane1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void backPanelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backPanelMouseExited
        ChangeColor(backPanel, new Color(240, 240, 240));
    }//GEN-LAST:event_backPanelMouseExited

    private void backPanelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backPanelMouseEntered
        ChangeColor(backPanel, new Color(0, 102, 180));
    }//GEN-LAST:event_backPanelMouseEntered

    private void backPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backPanelMouseClicked
        // TODO add your handling code here:
        new Home().setVisible(true);
        setVisible(false);        
        picLabel.setIcon(null);        
    }//GEN-LAST:event_backPanelMouseClicked

    private void retrieveMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_retrieveMouseClicked
        // TODO add your handling code here:
        retrieve();
        picLabel.setIcon(null);
        
        try {
            Connection con = DriverManager.getConnection(conString, username, password);
            
            PreparedStatement ps = con.prepareStatement("SELECT `MobilePic_b` FROM `image` WHERE MobileName='" + mName + "'");
            ResultSet rs = ps.executeQuery();
byte[] image = null;
        while (rs.next()) {
            image = rs.getBytes("MobilePic_b");

        }
        Image img = Toolkit.getDefaultToolkit().createImage(image);
        ImageIcon icon = new ImageIcon(img);
        
        picLabel.setIcon(icon);
        
    } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }

    setVisible(true);
    }//GEN-LAST:event_retrieveMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MobileDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MobileDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MobileDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MobileDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MobileDetails().setVisible(true);
                
                
            }
        });

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable BatteryTable;
    private javax.swing.JTable BuildTable;
    private javax.swing.JTable CameraTable;
    private javax.swing.JTable ConnectivityTable;
    private javax.swing.JTable DisplayTable;
    private javax.swing.JTable FeaturesTable;
    private javax.swing.JTable FrequencyTable;
    private javax.swing.JTable MemoryTable;
    private javax.swing.JTable PriceTable;
    private javax.swing.JTable ProcessorTable;
    private javax.swing.JTable RatingsTable;
    private javax.swing.JPanel backPanel;
    private javax.swing.JPanel header;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel74;
    private javax.swing.JPanel jPanel75;
    private javax.swing.JPanel jPanel76;
    private javax.swing.JPanel jPanel77;
    private javax.swing.JPanel jPanel78;
    private javax.swing.JPanel jPanel79;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel80;
    private javax.swing.JPanel jPanel81;
    private javax.swing.JPanel jPanel82;
    private javax.swing.JPanel jPanel83;
    private javax.swing.JPanel jPanel84;
    private javax.swing.JPanel jPanel85;
    private javax.swing.JPanel jPanel86;
    private javax.swing.JPanel jPanel87;
    private javax.swing.JPanel jPanel88;
    private javax.swing.JPanel jPanel89;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane20;
    private javax.swing.JScrollPane jScrollPane21;
    private javax.swing.JScrollPane jScrollPane22;
    private javax.swing.JScrollPane jScrollPane23;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JLabel mobileNameLabel;
    private javax.swing.JLabel picLabel;
    private javax.swing.JButton retrieve;
    // End of variables declaration//GEN-END:variables
}
