package whatmobile;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.table.DefaultTableModel;

public class DBUpdater {

    String conString = "jdbc:mysql://localhost:3306/what_mobile";
    String username = "root";
    String password = "";

        //RETRIEVE DATA
    public DefaultTableModel getDataBuild(String Name) {
        //ADD COLUMNS TO TABLE MODEL
        DefaultTableModel builddm = new DefaultTableModel();
        
        //build
        builddm.addColumn("OS");
        builddm.addColumn("UI");
        builddm.addColumn("DIMENSIONS");
        builddm.addColumn("WEIGHT");
        builddm.addColumn("SIM");
        builddm.addColumn("COLORS");    
        //SQL STATEMENT
        String build = "SELECT OS,UI,Dimensions,Weight,SIM,Colors FROM build WHERE MobileName='"+Name+"'  ";

        try {
            Connection con = DriverManager.getConnection(conString, username, password);

            //PREPARED STMT
            //build
            Statement buildcon = con.prepareStatement(build);
            ResultSet buildRows = buildcon.executeQuery(build);//price
            
            //LOOP THRU GETTING ALL VALUES
            while (buildRows.next()) {
                //GET VALUES OF Build
                String os = buildRows.getString(1);
                String ui = buildRows.getString(2);
                String dimensions = buildRows.getString(3);
                String weight = buildRows.getString(4);
                String sim = buildRows.getString(5);
                String colors = buildRows.getString(6);

                builddm.addRow(new String[]{os, ui, dimensions, weight, sim, colors});
                
                
            }
            return builddm;
           

        } catch (Exception ex) {
            ex.printStackTrace();
            Logger.getLogger(DBUpdater.class.getName()).log(Level.SEVERE, null, ex);
        }

        return null;

    }
    
    
    public DefaultTableModel getDataFrequency(String Name) {
        DefaultTableModel  frequencydm= new DefaultTableModel();
        //frequency
        frequencydm.addColumn("2G Band");
        frequencydm.addColumn("3G Band");
        frequencydm.addColumn("4G Band");
        //SQL STATEMENT
        String frequency = "SELECT `2G_Band`,`3G_Band`,`4G_Band`,`5GBand` FROM `frequency` WHERE MobileName='"+Name+"'  ";
       try {
            Connection con = DriverManager.getConnection(conString, username, password);
            //frequency
            Statement frequencycon = con.prepareStatement(frequency);
            ResultSet frequencyRows = frequencycon.executeQuery(frequency);
            //LOOP THRU GETTING ALL VALUES
            while (frequencyRows.next()) {
                //GET VALUES OF frequency
                 String Band2g = frequencyRows.getString(1);
                String Band3g = frequencyRows.getString(2);
                String Band4g = frequencyRows.getString(3);

                frequencydm.addRow(new String[]{Band2g, Band3g, Band4g});
            }
            return frequencydm;
                
            }catch (Exception ex) {
            ex.printStackTrace();
            Logger.getLogger(DBUpdater.class.getName()).log(Level.SEVERE, null, ex);
        }
       return null;
    }
    
    public DefaultTableModel getDataProcessor(String Name) {
        DefaultTableModel Processordm = new DefaultTableModel();
        //Processor
        Processordm.addColumn("CPU");
        Processordm.addColumn("Chipset");
        Processordm.addColumn("GPU");
        //SQL STATEMENT
        String Processor = "SELECT`CPU`,`Chipset`,`GPU` FROM `processor` WHERE MobileName='"+Name+"'  ";
        
       try {
            Connection con = DriverManager.getConnection(conString, username, password);
           //Processor
            Statement Processorcon = con.prepareStatement(Processor);
            ResultSet ProcessorRows = Processorcon.executeQuery(Processor);
            //LOOP THRU GETTING ALL VALUES
            while (ProcessorRows.next()) {
                //GET VALUES OF frequency
                 String cpu = ProcessorRows.getString(1);
                String chipset = ProcessorRows.getString(2);
                String gpu = ProcessorRows.getString(3);

                Processordm.addRow(new String[]{cpu, chipset, gpu});
            }
            return Processordm;
                
            }catch (Exception ex) {
            ex.printStackTrace();
            Logger.getLogger(DBUpdater.class.getName()).log(Level.SEVERE, null, ex);
        }
       return null;
    }
    
    public DefaultTableModel getDataMemory(String Name) {
        DefaultTableModel Memorydm = new DefaultTableModel();
        //Memory
        Memorydm.addColumn("Built-in");
        Memorydm.addColumn("Card");
        //SQL STATEMENT
         String Memory = "SELECT `Built-in`,`Card` FROM `memory` WHERE MobileName='"+Name+"'  ";
        
        
       try {
            Connection con = DriverManager.getConnection(conString, username, password);
           //Memory
            Statement Memorycon = con.prepareStatement(Memory);
            ResultSet MemoryRows = Memorycon.executeQuery(Memory);
            //LOOP THRU GETTING ALL VALUES
            while (MemoryRows.next()) {
                //GET VALUES OF frequency
                 String internal = MemoryRows.getString(1);
                String Card = MemoryRows.getString(2);
                

                Memorydm.addRow(new String[]{internal, Card});
            }
            return Memorydm;
                
            }catch (Exception ex) {
            ex.printStackTrace();
            Logger.getLogger(DBUpdater.class.getName()).log(Level.SEVERE, null, ex);
        }
       return null;
    }
    
    
    public DefaultTableModel getDataDisplay(String Name) {
        DefaultTableModel Displaydm = new DefaultTableModel();
        //Display
        Displaydm.addColumn("Technology");
        Displaydm.addColumn("Size");
        Displaydm.addColumn("Resolution");
        //SQL STATEMENT
       String Display = "SELECT `Technology`,`Size`,`Resolution`,`Extra_Features` FROM `display` WHERE MobileName='"+Name+"'  ";
       
        
       try {
            Connection con = DriverManager.getConnection(conString, username, password);
            //Display
            Statement Displaycon = con.prepareStatement(Display);
            ResultSet DisplayRows = Displaycon.executeQuery(Display);
            //LOOP THRU GETTING ALL VALUES
            while (DisplayRows.next()) {
                //GET VALUES OF frequency
                 String Technology = DisplayRows.getString(1);
                String Size = DisplayRows.getString(2);
                String Resolution = DisplayRows.getString(3);
                String Extra_Features = DisplayRows.getString(4);
                
                Displaydm.addRow(new String[]{Technology, Size, Resolution, Extra_Features});
            }
            return Displaydm;
                
            }catch (Exception ex) {
            ex.printStackTrace();
            Logger.getLogger(DBUpdater.class.getName()).log(Level.SEVERE, null, ex);
        }
       return null;
    }
    
     public DefaultTableModel getDataCamera(String Name) {
        DefaultTableModel Cameradm = new DefaultTableModel();
        //Camera
        Cameradm.addColumn("Main");
        Cameradm.addColumn("Features");
        Cameradm.addColumn("Front");
        //SQL STATEMENT
       String Camera = "SELECT `Main`,`Features`,`Front` FROM `camera` WHERE MobileName='"+Name+"'";
        
        
       try {
            Connection con = DriverManager.getConnection(conString, username, password);
            //Camera
            Statement Cameracon = con.prepareStatement(Camera);
            ResultSet CameraRows = Cameracon.executeQuery(Camera);
            //LOOP THRU GETTING ALL VALUES
            while (CameraRows.next()) {
                //GET VALUES OF frequency
                 String Main = CameraRows.getString(1);
                String Features = CameraRows.getString(2);
                String Front = CameraRows.getString(3);
                
                
                Cameradm.addRow(new String[]{Main, Features, Front});
            }
            return Cameradm;
                
            }catch (Exception ex) {
            ex.printStackTrace();
            Logger.getLogger(DBUpdater.class.getName()).log(Level.SEVERE, null, ex);
        }
       return null;
    }
     
     
     public DefaultTableModel getDataConnectivity(String Name) {
        DefaultTableModel Connectivitydm = new DefaultTableModel();
        //Connectivity
        Connectivitydm.addColumn("WLAN");
        Connectivitydm.addColumn("Bluetooth");
        Connectivitydm.addColumn("GPS");
        Connectivitydm.addColumn("Radio");
        Connectivitydm.addColumn("USB");
        Connectivitydm.addColumn("NFC");
        Connectivitydm.addColumn("Data");
        //SQL STATEMENT
       String Connectivity = "SELECT  `WLAN`,`Bluetooth`,`GPS`,`Radio`,`USB`,`NFC`,`Data` FROM `connectivity` WHERE MobileName='"+Name+"'  ";
        
       try {
            Connection con = DriverManager.getConnection(conString, username, password);
           //Connectivity
            Statement Connectivitycon = con.prepareStatement(Connectivity);
            ResultSet ConnectivityRows = Connectivitycon.executeQuery(Connectivity);
            //LOOP THRU GETTING ALL VALUES
            while (ConnectivityRows.next()) {
                //GET VALUES OF frequency
                 String WLAN = ConnectivityRows.getString(1);
                String Bluetooth = ConnectivityRows.getString(2);
                String GPS = ConnectivityRows.getString(3);
                String Radio = ConnectivityRows.getString(4);
                String USB = ConnectivityRows.getString(5);
                String NFC = ConnectivityRows.getString(6);
                String Data = ConnectivityRows.getString(7);
                
                Connectivitydm.addRow(new String[]{WLAN, Bluetooth, GPS, Radio, USB, NFC,Data });
            }
            return Connectivitydm;
                
            }catch (Exception ex) {
            ex.printStackTrace();
            Logger.getLogger(DBUpdater.class.getName()).log(Level.SEVERE, null, ex);
        }
       return null;
    }
     
     public DefaultTableModel getDataFeatures(String Name) {
        DefaultTableModel Featuresdm = new DefaultTableModel();
       //Features
        Featuresdm.addColumn("Sensors");
        Featuresdm.addColumn("Audio");
        Featuresdm.addColumn("Browser");
        Featuresdm.addColumn("Messaging");
        Featuresdm.addColumn("Games");
        Featuresdm.addColumn("Torch");
        Featuresdm.addColumn("Extra");
        //SQL STATEMENT
       String Features = "SELECT `Sensors`,`Audio`,`Browser`,`Messaging`,`Games`,`Torch`,`Extra` FROM `features` WHERE MobileName='"+Name+"'";
        
       try {
            Connection con = DriverManager.getConnection(conString, username, password);
            //Features
            Statement Featurescon = con.prepareStatement(Features);
            ResultSet FeaturesRows = Featurescon.executeQuery(Features);
            //LOOP THRU GETTING ALL VALUES
            while (FeaturesRows.next()) {
                //GET VALUES OF frequency
                 String Sensors = FeaturesRows.getString(1);
                String Audio =FeaturesRows.getString(2);
                String Browser = FeaturesRows.getString(3);
                String Messaging = FeaturesRows.getString(4);
                String Games= FeaturesRows.getString(5);
                String Torch = FeaturesRows.getString(6);
                String Extra = FeaturesRows.getString(7);
                
                Featuresdm.addRow(new String[]{Sensors, Audio, Browser, Messaging, Games, Torch, Extra });
            }
            return Featuresdm;
                
            }catch (Exception ex) {
            ex.printStackTrace();
            Logger.getLogger(DBUpdater.class.getName()).log(Level.SEVERE, null, ex);
        }
       return null;
    }
     
     public DefaultTableModel getDataBattery(String Name) {
        DefaultTableModel Batterydm = new DefaultTableModel();
       //Battery
        Batterydm.addColumn("Battery");
        //SQL STATEMENT
       String Battery = "SELECT `Capacity` FROM `battery` WHERE MobileName='"+Name+"'  ";
       
       try {
            Connection con = DriverManager.getConnection(conString, username, password);
            //Battery
            Statement Batterycon = con.prepareStatement(Battery);
            ResultSet BatteryRows = Batterycon.executeQuery(Battery);
            //LOOP THRU GETTING ALL VALUES
            while (BatteryRows.next()) {
                //GET VALUES OF frequency
                 String Capacity = BatteryRows.getString(1);
                              
                Batterydm.addRow(new String[]{Capacity});
            }
            return Batterydm;
                
            }catch (Exception ex) {
            ex.printStackTrace();
            Logger.getLogger(DBUpdater.class.getName()).log(Level.SEVERE, null, ex);
        }
       return null;
    }
     
     public DefaultTableModel getDataPrice(String Name) {
        DefaultTableModel pricedm = new DefaultTableModel();
       //Battery
        pricedm.addColumn("Price");
        //SQL STATEMENT
       String price = "SELECT `Price` FROM `price` WHERE MobileName='"+Name+"'  ";
       
       try {
            Connection con = DriverManager.getConnection(conString, username, password);
            //Battery
            Statement pricecon = con.prepareStatement(price);
            ResultSet priceRows = pricecon.executeQuery(price);
            //LOOP THRU GETTING ALL VALUES
            while (priceRows.next()) {
                //GET VALUES OF frequency
                 String prices = priceRows.getString(1);
                              
                pricedm.addRow(new String[]{prices});
            }
            return pricedm;
                
            }catch (Exception ex) {
            ex.printStackTrace();
            Logger.getLogger(DBUpdater.class.getName()).log(Level.SEVERE, null, ex);
        }
       return null;
    }
     
     public DefaultTableModel getDataRatings(String Name) {
        DefaultTableModel ratingsdm = new DefaultTableModel();
       //Battery
        ratingsdm.addColumn("Ratings");
        //SQL STATEMENT
       String ratings = "SELECT `Ratings` FROM `price` WHERE MobileName='"+Name+"'  ";
       
       try {
            Connection con = DriverManager.getConnection(conString, username, password);
            //Battery
            Statement ratingcon = con.prepareStatement(ratings);
            ResultSet ratingRows = ratingcon.executeQuery(ratings);
            //LOOP THRU GETTING ALL VALUES
            while (ratingRows.next()) {
                //GET VALUES OF frequency
                 String rating = ratingRows.getString(1);
                              
                ratingsdm.addRow(new String[]{rating});
            }
            return ratingsdm;
                
            }catch (Exception ex) {
            ex.printStackTrace();
            Logger.getLogger(DBUpdater.class.getName()).log(Level.SEVERE, null, ex);
        }
       return null;
    }      
}