/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.swing.table.DefaultTableModel;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author abdul
 */
public class DBUpdaterTest {
    
    public DBUpdaterTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of add method, of class DBUpdater.
     */
    @Test
    public void testAdd() {
        System.out.println("add");
        String id = "";
        String StuName = "";
        String StuReport = "";
        DBUpdater instance = new DBUpdater();
        Boolean expResult = null;
        Boolean result = instance.add(id, StuName, StuReport);
        assertEquals(result, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getData method, of class DBUpdater.
     */
    @Test
    public void testGetData() {
        System.out.println("getData");
        DBUpdater instance = new DBUpdater();
        DefaultTableModel expResult = null;
        DefaultTableModel result = instance.getData();
        assertEquals(result, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of update method, of class DBUpdater.
     */
    @Test
    public void testUpdate() {
        System.out.println("update");
        String id = "";
        String name = "";
        String report = "";
        DBUpdater instance = new DBUpdater();
        Boolean expResult = null;
        Boolean result = instance.update(id, name, report);
        assertEquals(result, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of delete method, of class DBUpdater.
     */
    @Test
    public void testDelete() {
        System.out.println("delete");
        String id = "";
        DBUpdater instance = new DBUpdater();
        Boolean expResult = null;
        Boolean result = instance.delete(id);
        assertEquals(result, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
