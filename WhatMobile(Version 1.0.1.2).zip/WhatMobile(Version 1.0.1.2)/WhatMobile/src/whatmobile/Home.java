package whatmobile;

import java.awt.*;
import javax.swing.*;

public class Home extends javax.swing.JFrame {

    boolean a = false;

    public Home() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        header = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        searchTextField = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        searchButton = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        menu = new javax.swing.JPanel();
        menuIcons = new javax.swing.JPanel();
        lineMenu = new javax.swing.JPanel();
        menuPanel = new javax.swing.JPanel();
        iMenu = new javax.swing.JLabel();
        lineMobiles = new javax.swing.JPanel();
        mobilesPanel = new javax.swing.JPanel();
        iMobiles = new javax.swing.JLabel();
        lineNews = new javax.swing.JPanel();
        newsPanel = new javax.swing.JPanel();
        iNews = new javax.swing.JLabel();
        lineMail = new javax.swing.JPanel();
        mailPanel = new javax.swing.JPanel();
        iMail = new javax.swing.JLabel();
        lineShop = new javax.swing.JPanel();
        shopPanel = new javax.swing.JPanel();
        iShop = new javax.swing.JLabel();
        menuHide = new javax.swing.JPanel();
        lineMobiles2 = new javax.swing.JPanel();
        mobilesPanel2 = new javax.swing.JPanel();
        iMobiles1 = new javax.swing.JLabel();
        lineNews2 = new javax.swing.JPanel();
        lineMail2 = new javax.swing.JPanel();
        lineShop2 = new javax.swing.JPanel();
        newsPanel2 = new javax.swing.JPanel();
        iNews1 = new javax.swing.JLabel();
        mailPanel1 = new javax.swing.JPanel();
        iMail1 = new javax.swing.JLabel();
        shopPanel1 = new javax.swing.JPanel();
        iShop1 = new javax.swing.JLabel();
        menuPanel1 = new javax.swing.JPanel();
        iMenu1 = new javax.swing.JLabel();
        lineMenu1 = new javax.swing.JPanel();
        dashBoardView = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        DashboardTabbedPane = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        items = new javax.swing.JPanel();
        outerPanel1 = new javax.swing.JPanel();
        innerPanel1 = new javax.swing.JPanel();
        picLabel1 = new javax.swing.JLabel();
        mobileNameLabel1 = new javax.swing.JLabel();
        mobilePriceLabel1 = new javax.swing.JLabel();
        outerPanel2 = new javax.swing.JPanel();
        innerPanel2 = new javax.swing.JPanel();
        picLabel2 = new javax.swing.JLabel();
        mobileNameLabel2 = new javax.swing.JLabel();
        mobilePriceLabel2 = new javax.swing.JLabel();
        outerPanel3 = new javax.swing.JPanel();
        innerPanel3 = new javax.swing.JPanel();
        picLabel3 = new javax.swing.JLabel();
        mobileNameLabel3 = new javax.swing.JLabel();
        mobilePriceLabel3 = new javax.swing.JLabel();
        outerPanel4 = new javax.swing.JPanel();
        innerPanel4 = new javax.swing.JPanel();
        picLabel4 = new javax.swing.JLabel();
        mobileNameLabel4 = new javax.swing.JLabel();
        mobilePriceLabel4 = new javax.swing.JLabel();
        outerPanel5 = new javax.swing.JPanel();
        innerPanel5 = new javax.swing.JPanel();
        picLabel5 = new javax.swing.JLabel();
        mobileNameLabel5 = new javax.swing.JLabel();
        mobilePriceLabel5 = new javax.swing.JLabel();
        outerPanel6 = new javax.swing.JPanel();
        innerPanel6 = new javax.swing.JPanel();
        picLabel6 = new javax.swing.JLabel();
        mobileNameLabel6 = new javax.swing.JLabel();
        mobilePriceLabel6 = new javax.swing.JLabel();
        outerPanel8 = new javax.swing.JPanel();
        innerPanel8 = new javax.swing.JPanel();
        picLabel8 = new javax.swing.JLabel();
        mobileNameLabel8 = new javax.swing.JLabel();
        mobilePriceLabel8 = new javax.swing.JLabel();
        outerPanel9 = new javax.swing.JPanel();
        innerPanel9 = new javax.swing.JPanel();
        picLabel9 = new javax.swing.JLabel();
        mobileNameLabel9 = new javax.swing.JLabel();
        mobilePriceLabel9 = new javax.swing.JLabel();
        outerPanel10 = new javax.swing.JPanel();
        innerPanel10 = new javax.swing.JPanel();
        picLabel10 = new javax.swing.JLabel();
        mobileNameLabel10 = new javax.swing.JLabel();
        mobilePriceLabel10 = new javax.swing.JLabel();
        outerPanel11 = new javax.swing.JPanel();
        innerPanel11 = new javax.swing.JPanel();
        picLabel11 = new javax.swing.JLabel();
        mobileNameLabel11 = new javax.swing.JLabel();
        mobilePriceLabel11 = new javax.swing.JLabel();
        outerPanel12 = new javax.swing.JPanel();
        innerPanel12 = new javax.swing.JPanel();
        picLabel12 = new javax.swing.JLabel();
        mobileNameLabel12 = new javax.swing.JLabel();
        mobilePriceLabel12 = new javax.swing.JLabel();
        outerPanel13 = new javax.swing.JPanel();
        innerPanel13 = new javax.swing.JPanel();
        picLabel13 = new javax.swing.JLabel();
        mobileNameLabel13 = new javax.swing.JLabel();
        mobilePriceLabel13 = new javax.swing.JLabel();
        outerPanel15 = new javax.swing.JPanel();
        innerPanel15 = new javax.swing.JPanel();
        picLabel15 = new javax.swing.JLabel();
        mobileNameLabel15 = new javax.swing.JLabel();
        mobilePriceLabel15 = new javax.swing.JLabel();
        outerPanel17 = new javax.swing.JPanel();
        innerPanel17 = new javax.swing.JPanel();
        picLabel17 = new javax.swing.JLabel();
        mobileNameLabel17 = new javax.swing.JLabel();
        mobilePriceLabel17 = new javax.swing.JLabel();
        outerPanel18 = new javax.swing.JPanel();
        innerPanel18 = new javax.swing.JPanel();
        picLabel18 = new javax.swing.JLabel();
        mobileNameLabel18 = new javax.swing.JLabel();
        mobilePriceLabel18 = new javax.swing.JLabel();
        outerPanel19 = new javax.swing.JPanel();
        innerPanel19 = new javax.swing.JPanel();
        picLabel19 = new javax.swing.JLabel();
        mobileNameLabel19 = new javax.swing.JLabel();
        mobilePriceLabel19 = new javax.swing.JLabel();
        outerPanel20 = new javax.swing.JPanel();
        innerPanel20 = new javax.swing.JPanel();
        picLabel20 = new javax.swing.JLabel();
        mobileNameLabel20 = new javax.swing.JLabel();
        mobilePriceLabel20 = new javax.swing.JLabel();
        outerPanel21 = new javax.swing.JPanel();
        innerPanel21 = new javax.swing.JPanel();
        picLabel21 = new javax.swing.JLabel();
        mobileNameLabel21 = new javax.swing.JLabel();
        mobilePriceLabel21 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        header.setBackground(new java.awt.Color(36, 87, 152));
        header.setPreferredSize(new java.awt.Dimension(999, 150));
        header.setLayout(new java.awt.BorderLayout());

        jPanel5.setBackground(new java.awt.Color(36, 87, 152));
        jPanel5.setMinimumSize(new java.awt.Dimension(170, 40));
        jPanel5.setPreferredSize(new java.awt.Dimension(400, 40));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        searchTextField.setToolTipText("");
        searchTextField.setName(""); // NOI18N
        jPanel5.add(searchTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 240, 40));

        jPanel6.setBackground(new java.awt.Color(255, 0, 255));
        jPanel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel6MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel6MouseExited(evt);
            }
        });
        jPanel6.setLayout(new java.awt.BorderLayout());

        searchButton.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        searchButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/icons8_search_32.png"))); // NOI18N
        jPanel6.add(searchButton, java.awt.BorderLayout.CENTER);

        jPanel5.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 60, 70, 40));

        header.add(jPanel5, java.awt.BorderLayout.LINE_END);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/11070823_798808190167734_5912407124608451387_n.png"))); // NOI18N
        header.add(jLabel1, java.awt.BorderLayout.CENTER);

        getContentPane().add(header, java.awt.BorderLayout.PAGE_START);

        menu.setBackground(new java.awt.Color(36, 87, 152));
        menu.setPreferredSize(new java.awt.Dimension(270, 400));
        menu.setLayout(new java.awt.BorderLayout());

        menuIcons.setBackground(new java.awt.Color(10, 36, 101));
        menuIcons.setPreferredSize(new java.awt.Dimension(60, 400));
        menuIcons.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lineMenu.setBackground(new java.awt.Color(10, 36, 101));
        lineMenu.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineMenuLayout = new javax.swing.GroupLayout(lineMenu);
        lineMenu.setLayout(lineMenuLayout);
        lineMenuLayout.setHorizontalGroup(
            lineMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        lineMenuLayout.setVerticalGroup(
            lineMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuIcons.add(lineMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 60, 5));

        menuPanel.setBackground(new java.awt.Color(10, 36, 101));
        menuPanel.setLayout(new java.awt.BorderLayout());

        iMenu.setBackground(new java.awt.Color(10, 36, 101));
        iMenu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/icons8_menu_48.png"))); // NOI18N
        iMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iMenuMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iMenuMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iMenuMouseExited(evt);
            }
        });
        menuPanel.add(iMenu, java.awt.BorderLayout.CENTER);

        menuIcons.add(menuPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 5, 60, 60));

        lineMobiles.setBackground(new java.awt.Color(10, 36, 101));
        lineMobiles.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineMobilesLayout = new javax.swing.GroupLayout(lineMobiles);
        lineMobiles.setLayout(lineMobilesLayout);
        lineMobilesLayout.setHorizontalGroup(
            lineMobilesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        lineMobilesLayout.setVerticalGroup(
            lineMobilesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuIcons.add(lineMobiles, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 65, 60, 5));

        mobilesPanel.setBackground(new java.awt.Color(10, 36, 101));
        mobilesPanel.setLayout(new java.awt.BorderLayout());

        iMobiles.setBackground(new java.awt.Color(10, 36, 101));
        iMobiles.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iMobiles.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/icons8_mobile_48.png"))); // NOI18N
        iMobiles.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iMobilesMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iMobilesMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iMobilesMouseExited(evt);
            }
        });
        mobilesPanel.add(iMobiles, java.awt.BorderLayout.CENTER);

        menuIcons.add(mobilesPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 60, 60));

        lineNews.setBackground(new java.awt.Color(10, 36, 101));
        lineNews.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineNewsLayout = new javax.swing.GroupLayout(lineNews);
        lineNews.setLayout(lineNewsLayout);
        lineNewsLayout.setHorizontalGroup(
            lineNewsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        lineNewsLayout.setVerticalGroup(
            lineNewsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuIcons.add(lineNews, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 60, 5));

        newsPanel.setBackground(new java.awt.Color(10, 36, 101));
        newsPanel.setLayout(new java.awt.BorderLayout());

        iNews.setBackground(new java.awt.Color(10, 36, 101));
        iNews.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iNews.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/icons8_news_48.png"))); // NOI18N
        iNews.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iNewsMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iNewsMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iNewsMouseExited(evt);
            }
        });
        newsPanel.add(iNews, java.awt.BorderLayout.CENTER);

        menuIcons.add(newsPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 135, 60, 60));

        lineMail.setBackground(new java.awt.Color(10, 36, 101));
        lineMail.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineMailLayout = new javax.swing.GroupLayout(lineMail);
        lineMail.setLayout(lineMailLayout);
        lineMailLayout.setHorizontalGroup(
            lineMailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        lineMailLayout.setVerticalGroup(
            lineMailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuIcons.add(lineMail, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 195, 60, 5));

        mailPanel.setBackground(new java.awt.Color(10, 36, 101));
        mailPanel.setLayout(new java.awt.BorderLayout());

        iMail.setBackground(new java.awt.Color(10, 36, 101));
        iMail.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iMail.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/icons8_mailbox_48.png"))); // NOI18N
        iMail.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iMailMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iMailMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iMailMouseExited(evt);
            }
        });
        mailPanel.add(iMail, java.awt.BorderLayout.CENTER);

        menuIcons.add(mailPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 60, 60));

        lineShop.setBackground(new java.awt.Color(10, 36, 101));
        lineShop.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineShopLayout = new javax.swing.GroupLayout(lineShop);
        lineShop.setLayout(lineShopLayout);
        lineShopLayout.setHorizontalGroup(
            lineShopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        lineShopLayout.setVerticalGroup(
            lineShopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuIcons.add(lineShop, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 260, 60, 5));

        shopPanel.setBackground(new java.awt.Color(10, 36, 101));
        shopPanel.setLayout(new java.awt.BorderLayout());

        iShop.setBackground(new java.awt.Color(10, 36, 101));
        iShop.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iShop.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/icons8_shop_48.png"))); // NOI18N
        iShop.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iShopMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iShopMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iShopMouseExited(evt);
            }
        });
        shopPanel.add(iShop, java.awt.BorderLayout.CENTER);

        menuIcons.add(shopPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 265, 60, 60));

        menu.add(menuIcons, java.awt.BorderLayout.LINE_START);

        menuHide.setBackground(new java.awt.Color(102, 102, 255));
        menuHide.setRequestFocusEnabled(false);
        menuHide.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lineMobiles2.setBackground(new java.awt.Color(10, 36, 101));
        lineMobiles2.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineMobiles2Layout = new javax.swing.GroupLayout(lineMobiles2);
        lineMobiles2.setLayout(lineMobiles2Layout);
        lineMobiles2Layout.setHorizontalGroup(
            lineMobiles2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 210, Short.MAX_VALUE)
        );
        lineMobiles2Layout.setVerticalGroup(
            lineMobiles2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuHide.add(lineMobiles2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 65, 210, 5));

        mobilesPanel2.setBackground(new java.awt.Color(10, 36, 101));
        mobilesPanel2.setLayout(new java.awt.BorderLayout());

        iMobiles1.setBackground(new java.awt.Color(0, 0, 0));
        iMobiles1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        iMobiles1.setForeground(new java.awt.Color(255, 255, 255));
        iMobiles1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iMobiles1.setText("Mobiles");
        iMobiles1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iMobiles1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iMobiles1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iMobiles1MouseExited(evt);
            }
        });
        mobilesPanel2.add(iMobiles1, java.awt.BorderLayout.CENTER);

        menuHide.add(mobilesPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 210, 60));

        lineNews2.setBackground(new java.awt.Color(10, 36, 101));
        lineNews2.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineNews2Layout = new javax.swing.GroupLayout(lineNews2);
        lineNews2.setLayout(lineNews2Layout);
        lineNews2Layout.setHorizontalGroup(
            lineNews2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 210, Short.MAX_VALUE)
        );
        lineNews2Layout.setVerticalGroup(
            lineNews2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuHide.add(lineNews2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 210, 5));

        lineMail2.setBackground(new java.awt.Color(10, 36, 101));
        lineMail2.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineMail2Layout = new javax.swing.GroupLayout(lineMail2);
        lineMail2.setLayout(lineMail2Layout);
        lineMail2Layout.setHorizontalGroup(
            lineMail2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 210, Short.MAX_VALUE)
        );
        lineMail2Layout.setVerticalGroup(
            lineMail2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuHide.add(lineMail2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 195, 210, 5));

        lineShop2.setBackground(new java.awt.Color(10, 36, 101));
        lineShop2.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineShop2Layout = new javax.swing.GroupLayout(lineShop2);
        lineShop2.setLayout(lineShop2Layout);
        lineShop2Layout.setHorizontalGroup(
            lineShop2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 210, Short.MAX_VALUE)
        );
        lineShop2Layout.setVerticalGroup(
            lineShop2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuHide.add(lineShop2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 260, 210, 5));

        newsPanel2.setBackground(new java.awt.Color(10, 36, 101));
        newsPanel2.setLayout(new java.awt.BorderLayout());

        iNews1.setBackground(new java.awt.Color(0, 0, 0));
        iNews1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        iNews1.setForeground(new java.awt.Color(255, 255, 255));
        iNews1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iNews1.setText("News");
        iNews1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iNews1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iNews1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iNews1MouseExited(evt);
            }
        });
        newsPanel2.add(iNews1, java.awt.BorderLayout.CENTER);

        menuHide.add(newsPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 135, 210, 60));

        mailPanel1.setBackground(new java.awt.Color(10, 36, 101));
        mailPanel1.setLayout(new java.awt.BorderLayout());

        iMail1.setBackground(new java.awt.Color(0, 0, 0));
        iMail1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        iMail1.setForeground(new java.awt.Color(255, 255, 255));
        iMail1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iMail1.setText("Contact Us");
        iMail1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iMail1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iMail1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iMail1MouseExited(evt);
            }
        });
        mailPanel1.add(iMail1, java.awt.BorderLayout.CENTER);

        menuHide.add(mailPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 210, 60));

        shopPanel1.setBackground(new java.awt.Color(10, 36, 101));
        shopPanel1.setLayout(new java.awt.BorderLayout());

        iShop1.setBackground(new java.awt.Color(0, 0, 0));
        iShop1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        iShop1.setForeground(new java.awt.Color(255, 255, 255));
        iShop1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iShop1.setText("Shopes");
        iShop1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iShop1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iShop1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iShop1MouseExited(evt);
            }
        });
        shopPanel1.add(iShop1, java.awt.BorderLayout.CENTER);

        menuHide.add(shopPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 265, 210, 60));

        menuPanel1.setBackground(new java.awt.Color(10, 36, 101));
        menuPanel1.setLayout(new java.awt.BorderLayout());

        iMenu1.setBackground(new java.awt.Color(10, 36, 101));
        iMenu1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iMenu1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iMenu1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iMenu1MouseExited(evt);
            }
        });
        menuPanel1.add(iMenu1, java.awt.BorderLayout.CENTER);

        menuHide.add(menuPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 5, 210, 60));

        lineMenu1.setBackground(new java.awt.Color(10, 36, 101));
        lineMenu1.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineMenu1Layout = new javax.swing.GroupLayout(lineMenu1);
        lineMenu1.setLayout(lineMenu1Layout);
        lineMenu1Layout.setHorizontalGroup(
            lineMenu1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 210, Short.MAX_VALUE)
        );
        lineMenu1Layout.setVerticalGroup(
            lineMenu1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuHide.add(lineMenu1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 210, 5));

        menu.add(menuHide, java.awt.BorderLayout.CENTER);

        getContentPane().add(menu, java.awt.BorderLayout.LINE_START);

        dashBoardView.setBackground(new java.awt.Color(51, 102, 255));
        dashBoardView.setLayout(new java.awt.BorderLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        items.setBackground(new java.awt.Color(255, 255, 255));
        items.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        outerPanel1.setBackground(new java.awt.Color(255, 255, 255));
        outerPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        innerPanel1.setBackground(java.awt.Color.white);
        innerPanel1.setLayout(new java.awt.BorderLayout());

        picLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        picLabel1.setText("jLabel4");
        innerPanel1.add(picLabel1, java.awt.BorderLayout.CENTER);

        outerPanel1.add(innerPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 110, 120));

        mobileNameLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mobileNameLabel1.setForeground(new java.awt.Color(102, 102, 102));
        mobileNameLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobileNameLabel1.setText("jLabel2");
        outerPanel1.add(mobileNameLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 100, 20));

        mobilePriceLabel1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mobilePriceLabel1.setForeground(new java.awt.Color(51, 51, 255));
        mobilePriceLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobilePriceLabel1.setText("jLabel3");
        outerPanel1.add(mobilePriceLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 100, 20));

        items.add(outerPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 20, 150, 200));

        outerPanel2.setBackground(java.awt.Color.white);
        outerPanel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                outerPanel2MouseClicked(evt);
            }
        });
        outerPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        innerPanel2.setBackground(java.awt.Color.white);
        innerPanel2.setLayout(new java.awt.BorderLayout());

        picLabel2.setBackground(new java.awt.Color(255, 255, 255));
        picLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        picLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/images/VivoX70Pro-s.jpg"))); // NOI18N
        innerPanel2.add(picLabel2, java.awt.BorderLayout.CENTER);

        outerPanel2.add(innerPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 110, 120));

        mobileNameLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mobileNameLabel2.setForeground(new java.awt.Color(102, 102, 102));
        mobileNameLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobileNameLabel2.setText("Vivo X70 Pro");
        mobileNameLabel2.setAlignmentY(0.0F);
        outerPanel2.add(mobileNameLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 100, 20));

        mobilePriceLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mobilePriceLabel2.setForeground(new java.awt.Color(51, 51, 255));
        mobilePriceLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobilePriceLabel2.setText("Rs. 139,999");
        mobilePriceLabel2.setAlignmentY(0.0F);
        outerPanel2.add(mobilePriceLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 100, 20));

        items.add(outerPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, 150, 200));

        outerPanel3.setBackground(new java.awt.Color(255, 255, 255));
        outerPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        innerPanel3.setBackground(java.awt.Color.white);
        innerPanel3.setLayout(new java.awt.BorderLayout());

        picLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        picLabel3.setText("jLabel4");
        innerPanel3.add(picLabel3, java.awt.BorderLayout.CENTER);

        outerPanel3.add(innerPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 110, 120));

        mobileNameLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mobileNameLabel3.setForeground(new java.awt.Color(102, 102, 102));
        mobileNameLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobileNameLabel3.setText("jLabel2");
        outerPanel3.add(mobileNameLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 100, 20));

        mobilePriceLabel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mobilePriceLabel3.setForeground(new java.awt.Color(51, 51, 255));
        mobilePriceLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobilePriceLabel3.setText("jLabel3");
        outerPanel3.add(mobilePriceLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 100, 20));

        items.add(outerPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 20, 150, 200));

        outerPanel4.setBackground(new java.awt.Color(255, 255, 255));
        outerPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        innerPanel4.setBackground(java.awt.Color.white);
        innerPanel4.setLayout(new java.awt.BorderLayout());

        picLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        picLabel4.setText("jLabel4");
        innerPanel4.add(picLabel4, java.awt.BorderLayout.CENTER);

        outerPanel4.add(innerPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 110, 120));

        mobileNameLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mobileNameLabel4.setForeground(new java.awt.Color(102, 102, 102));
        mobileNameLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobileNameLabel4.setText("jLabel2");
        outerPanel4.add(mobileNameLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 100, 20));

        mobilePriceLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mobilePriceLabel4.setForeground(new java.awt.Color(51, 51, 255));
        mobilePriceLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobilePriceLabel4.setText("jLabel3");
        outerPanel4.add(mobilePriceLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 100, 20));

        items.add(outerPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 20, 150, 200));

        outerPanel5.setBackground(new java.awt.Color(255, 255, 255));
        outerPanel5.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        outerPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        innerPanel5.setBackground(java.awt.Color.white);
        innerPanel5.setLayout(new java.awt.BorderLayout());

        picLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        picLabel5.setText("jLabel4");
        innerPanel5.add(picLabel5, java.awt.BorderLayout.CENTER);

        outerPanel5.add(innerPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 110, 120));

        mobileNameLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mobileNameLabel5.setForeground(new java.awt.Color(102, 102, 102));
        mobileNameLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobileNameLabel5.setText("jLabel2");
        outerPanel5.add(mobileNameLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 100, 20));

        mobilePriceLabel5.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mobilePriceLabel5.setForeground(new java.awt.Color(51, 51, 255));
        mobilePriceLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobilePriceLabel5.setText("jLabel3");
        outerPanel5.add(mobilePriceLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 100, 20));

        items.add(outerPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 20, 150, 200));

        outerPanel6.setBackground(new java.awt.Color(255, 255, 255));
        outerPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        innerPanel6.setBackground(java.awt.Color.white);
        innerPanel6.setLayout(new java.awt.BorderLayout());

        picLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        picLabel6.setText("jLabel4");
        innerPanel6.add(picLabel6, java.awt.BorderLayout.CENTER);

        outerPanel6.add(innerPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 110, 120));

        mobileNameLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mobileNameLabel6.setForeground(new java.awt.Color(102, 102, 102));
        mobileNameLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobileNameLabel6.setText("jLabel2");
        outerPanel6.add(mobileNameLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 100, 20));

        mobilePriceLabel6.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mobilePriceLabel6.setForeground(new java.awt.Color(51, 51, 255));
        mobilePriceLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobilePriceLabel6.setText("jLabel3");
        outerPanel6.add(mobilePriceLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 100, 20));

        items.add(outerPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 20, 150, 200));

        outerPanel8.setBackground(new java.awt.Color(255, 255, 255));
        outerPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        innerPanel8.setBackground(java.awt.Color.white);
        innerPanel8.setLayout(new java.awt.BorderLayout());

        picLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        picLabel8.setText("jLabel4");
        innerPanel8.add(picLabel8, java.awt.BorderLayout.CENTER);

        outerPanel8.add(innerPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 110, 120));

        mobileNameLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mobileNameLabel8.setForeground(new java.awt.Color(102, 102, 102));
        mobileNameLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobileNameLabel8.setText("jLabel2");
        outerPanel8.add(mobileNameLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 100, 20));

        mobilePriceLabel8.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mobilePriceLabel8.setForeground(new java.awt.Color(51, 51, 255));
        mobilePriceLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobilePriceLabel8.setText("jLabel3");
        outerPanel8.add(mobilePriceLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 100, 20));

        items.add(outerPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 510, 150, 200));

        outerPanel9.setBackground(new java.awt.Color(255, 255, 255));
        outerPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        innerPanel9.setBackground(java.awt.Color.white);
        innerPanel9.setLayout(new java.awt.BorderLayout());

        picLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        picLabel9.setText("jLabel4");
        innerPanel9.add(picLabel9, java.awt.BorderLayout.CENTER);

        outerPanel9.add(innerPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 110, 120));

        mobileNameLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mobileNameLabel9.setForeground(new java.awt.Color(102, 102, 102));
        mobileNameLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobileNameLabel9.setText("jLabel2");
        outerPanel9.add(mobileNameLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 100, 20));

        mobilePriceLabel9.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mobilePriceLabel9.setForeground(new java.awt.Color(51, 51, 255));
        mobilePriceLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobilePriceLabel9.setText("jLabel3");
        outerPanel9.add(mobilePriceLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 100, 20));

        items.add(outerPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 260, 150, 200));

        outerPanel10.setBackground(new java.awt.Color(255, 255, 255));
        outerPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        innerPanel10.setBackground(java.awt.Color.white);
        innerPanel10.setLayout(new java.awt.BorderLayout());

        picLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        picLabel10.setText("jLabel4");
        innerPanel10.add(picLabel10, java.awt.BorderLayout.CENTER);

        outerPanel10.add(innerPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 110, 120));

        mobileNameLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mobileNameLabel10.setForeground(new java.awt.Color(102, 102, 102));
        mobileNameLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobileNameLabel10.setText("jLabel2");
        outerPanel10.add(mobileNameLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 100, 20));

        mobilePriceLabel10.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mobilePriceLabel10.setForeground(new java.awt.Color(51, 51, 255));
        mobilePriceLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobilePriceLabel10.setText("jLabel3");
        outerPanel10.add(mobilePriceLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 100, 20));

        items.add(outerPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 260, 150, 200));

        outerPanel11.setBackground(new java.awt.Color(255, 255, 255));
        outerPanel11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        innerPanel11.setBackground(java.awt.Color.white);
        innerPanel11.setLayout(new java.awt.BorderLayout());

        picLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        picLabel11.setText("jLabel4");
        innerPanel11.add(picLabel11, java.awt.BorderLayout.CENTER);

        outerPanel11.add(innerPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 110, 120));

        mobileNameLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mobileNameLabel11.setForeground(new java.awt.Color(102, 102, 102));
        mobileNameLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobileNameLabel11.setText("jLabel2");
        outerPanel11.add(mobileNameLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 100, 20));

        mobilePriceLabel11.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mobilePriceLabel11.setForeground(new java.awt.Color(51, 51, 255));
        mobilePriceLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobilePriceLabel11.setText("jLabel3");
        outerPanel11.add(mobilePriceLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 100, 20));

        items.add(outerPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 260, 150, 200));

        outerPanel12.setBackground(new java.awt.Color(255, 255, 255));
        outerPanel12.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        innerPanel12.setBackground(java.awt.Color.white);
        innerPanel12.setLayout(new java.awt.BorderLayout());

        picLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        picLabel12.setText("jLabel4");
        innerPanel12.add(picLabel12, java.awt.BorderLayout.CENTER);

        outerPanel12.add(innerPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 110, 120));

        mobileNameLabel12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mobileNameLabel12.setForeground(new java.awt.Color(102, 102, 102));
        mobileNameLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobileNameLabel12.setText("jLabel2");
        outerPanel12.add(mobileNameLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 100, 20));

        mobilePriceLabel12.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mobilePriceLabel12.setForeground(new java.awt.Color(51, 51, 255));
        mobilePriceLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobilePriceLabel12.setText("jLabel3");
        outerPanel12.add(mobilePriceLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 100, 20));

        items.add(outerPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 260, 150, 200));

        outerPanel13.setBackground(new java.awt.Color(255, 255, 255));
        outerPanel13.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        innerPanel13.setBackground(java.awt.Color.white);
        innerPanel13.setLayout(new java.awt.BorderLayout());

        picLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        picLabel13.setText("jLabel4");
        innerPanel13.add(picLabel13, java.awt.BorderLayout.CENTER);

        outerPanel13.add(innerPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 110, 120));

        mobileNameLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mobileNameLabel13.setForeground(new java.awt.Color(102, 102, 102));
        mobileNameLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobileNameLabel13.setText("jLabel2");
        outerPanel13.add(mobileNameLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 100, 20));

        mobilePriceLabel13.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mobilePriceLabel13.setForeground(new java.awt.Color(51, 51, 255));
        mobilePriceLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobilePriceLabel13.setText("jLabel3");
        outerPanel13.add(mobilePriceLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 100, 20));

        items.add(outerPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 260, 150, 200));

        outerPanel15.setBackground(new java.awt.Color(255, 255, 255));
        outerPanel15.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        innerPanel15.setBackground(java.awt.Color.white);
        innerPanel15.setLayout(new java.awt.BorderLayout());

        picLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        picLabel15.setText("jLabel4");
        innerPanel15.add(picLabel15, java.awt.BorderLayout.CENTER);

        outerPanel15.add(innerPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 110, 120));

        mobileNameLabel15.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mobileNameLabel15.setForeground(new java.awt.Color(102, 102, 102));
        mobileNameLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobileNameLabel15.setText("jLabel2");
        outerPanel15.add(mobileNameLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 100, 20));

        mobilePriceLabel15.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mobilePriceLabel15.setForeground(new java.awt.Color(51, 51, 255));
        mobilePriceLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobilePriceLabel15.setText("jLabel3");
        outerPanel15.add(mobilePriceLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 100, 20));

        items.add(outerPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 260, 150, 200));

        outerPanel17.setBackground(new java.awt.Color(255, 255, 255));
        outerPanel17.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        innerPanel17.setBackground(java.awt.Color.white);
        innerPanel17.setLayout(new java.awt.BorderLayout());

        picLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        picLabel17.setText("jLabel4");
        innerPanel17.add(picLabel17, java.awt.BorderLayout.CENTER);

        outerPanel17.add(innerPanel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 110, 120));

        mobileNameLabel17.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mobileNameLabel17.setForeground(new java.awt.Color(102, 102, 102));
        mobileNameLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobileNameLabel17.setText("jLabel2");
        outerPanel17.add(mobileNameLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 100, 20));

        mobilePriceLabel17.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mobilePriceLabel17.setForeground(new java.awt.Color(51, 51, 255));
        mobilePriceLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobilePriceLabel17.setText("jLabel3");
        outerPanel17.add(mobilePriceLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 100, 20));

        items.add(outerPanel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 510, 150, 200));

        outerPanel18.setBackground(new java.awt.Color(255, 255, 255));
        outerPanel18.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        innerPanel18.setBackground(java.awt.Color.white);
        innerPanel18.setLayout(new java.awt.BorderLayout());

        picLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        picLabel18.setText("jLabel4");
        innerPanel18.add(picLabel18, java.awt.BorderLayout.CENTER);

        outerPanel18.add(innerPanel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 110, 120));

        mobileNameLabel18.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mobileNameLabel18.setForeground(new java.awt.Color(102, 102, 102));
        mobileNameLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobileNameLabel18.setText("jLabel2");
        outerPanel18.add(mobileNameLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 100, 20));

        mobilePriceLabel18.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mobilePriceLabel18.setForeground(new java.awt.Color(51, 51, 255));
        mobilePriceLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobilePriceLabel18.setText("jLabel3");
        outerPanel18.add(mobilePriceLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 100, 20));

        items.add(outerPanel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 510, 150, 200));

        outerPanel19.setBackground(new java.awt.Color(255, 255, 255));
        outerPanel19.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        innerPanel19.setBackground(java.awt.Color.white);
        innerPanel19.setLayout(new java.awt.BorderLayout());

        picLabel19.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        picLabel19.setText("jLabel4");
        innerPanel19.add(picLabel19, java.awt.BorderLayout.CENTER);

        outerPanel19.add(innerPanel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 110, 120));

        mobileNameLabel19.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mobileNameLabel19.setForeground(new java.awt.Color(102, 102, 102));
        mobileNameLabel19.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobileNameLabel19.setText("jLabel2");
        outerPanel19.add(mobileNameLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 100, 20));

        mobilePriceLabel19.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mobilePriceLabel19.setForeground(new java.awt.Color(51, 51, 255));
        mobilePriceLabel19.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobilePriceLabel19.setText("jLabel3");
        outerPanel19.add(mobilePriceLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 174, 100, 20));

        items.add(outerPanel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 510, 150, 200));

        outerPanel20.setBackground(new java.awt.Color(255, 255, 255));
        outerPanel20.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        innerPanel20.setBackground(java.awt.Color.white);
        innerPanel20.setLayout(new java.awt.BorderLayout());

        picLabel20.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        picLabel20.setText("jLabel4");
        innerPanel20.add(picLabel20, java.awt.BorderLayout.CENTER);

        outerPanel20.add(innerPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 110, 120));

        mobileNameLabel20.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mobileNameLabel20.setForeground(new java.awt.Color(102, 102, 102));
        mobileNameLabel20.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobileNameLabel20.setText("jLabel2");
        outerPanel20.add(mobileNameLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 100, 20));

        mobilePriceLabel20.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mobilePriceLabel20.setForeground(new java.awt.Color(51, 51, 255));
        mobilePriceLabel20.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobilePriceLabel20.setText("jLabel3");
        outerPanel20.add(mobilePriceLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 100, 20));

        items.add(outerPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 510, 150, 200));

        outerPanel21.setBackground(new java.awt.Color(255, 255, 255));
        outerPanel21.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        innerPanel21.setBackground(java.awt.Color.white);
        innerPanel21.setLayout(new java.awt.BorderLayout());

        picLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        picLabel21.setText("jLabel4");
        innerPanel21.add(picLabel21, java.awt.BorderLayout.CENTER);

        outerPanel21.add(innerPanel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 110, 120));

        mobileNameLabel21.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mobileNameLabel21.setForeground(new java.awt.Color(102, 102, 102));
        mobileNameLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobileNameLabel21.setText("jLabel2");
        outerPanel21.add(mobileNameLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 100, 20));

        mobilePriceLabel21.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        mobilePriceLabel21.setForeground(new java.awt.Color(51, 51, 255));
        mobilePriceLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mobilePriceLabel21.setText("jLabel3");
        outerPanel21.add(mobilePriceLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 100, 20));

        items.add(outerPanel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 510, 150, 200));
        items.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 490, 1310, 10));
        items.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 1310, 10));

        jPanel1.add(items, new org.netbeans.lib.awtextra.AbsoluteConstraints(3, 0, -1, -1));

        DashboardTabbedPane.addTab("Mobiles", jPanel1);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1316, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 710, Short.MAX_VALUE)
        );

        DashboardTabbedPane.addTab("News", jPanel2);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1316, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 710, Short.MAX_VALUE)
        );

        DashboardTabbedPane.addTab("Contact Us", jPanel3);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1316, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 710, Short.MAX_VALUE)
        );

        DashboardTabbedPane.addTab("Shopes", jPanel4);

        jScrollPane1.setViewportView(DashboardTabbedPane);

        dashBoardView.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        getContentPane().add(dashBoardView, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 1266, 761);
    }// </editor-fold>//GEN-END:initComponents

    public void ChangeColor(JPanel hover, Color rand) {
        hover.setBackground(rand);
    }

    public void changeimage(JLabel button, String resourcheimg) {
        ImageIcon aimg = new ImageIcon(getClass().getResource(resourcheimg));
        button.setIcon(aimg);
    }

    public void hideshow(JPanel menusHide, boolean dashBoardView, JLabel button) {
        if (dashBoardView == true) {
            menusHide.setPreferredSize(new Dimension(60, menusHide.getHeight()));

            changeimage(button, "/Whatmobile/icons/icons8_left_48.png");
        } else {
            menusHide.setPreferredSize(new Dimension(270, menusHide.getHeight()));

            changeimage(button, "/Whatmobile/icons/icons8_menu_48.png");

        }
    }


    private void iMenuMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMenuMouseEntered
        ChangeColor(lineMenu, new Color(247, 78, 104));
        ChangeColor(lineMenu1, new Color(247, 78, 104));
    }//GEN-LAST:event_iMenuMouseEntered

    private void iMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMenuMouseClicked
        mobilesPanel.setBackground(new Color(10, 36, 101));
        menuPanel.setBackground(new Color(36, 87, 152));
        mailPanel.setBackground(new Color(10, 36, 101));
        newsPanel.setBackground(new Color(10, 36, 101));
        shopPanel.setBackground(new Color(10, 36, 101));

        mobilesPanel2.setBackground(new Color(10, 36, 101));
        menuPanel1.setBackground(new Color(36, 87, 152));
        mailPanel1.setBackground(new Color(10, 36, 101));
        newsPanel2.setBackground(new Color(10, 36, 101));
        shopPanel1.setBackground(new Color(10, 36, 101));
        if (a == true) {
            hideshow(menu, a, iMenu);
            SwingUtilities.updateComponentTreeUI(this);
            a = false;
        } else {
            hideshow(menu, a, iMenu);
            SwingUtilities.updateComponentTreeUI(this);
            a = true;
        }
    }//GEN-LAST:event_iMenuMouseClicked

    private void iMenuMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMenuMouseExited
        ChangeColor(lineMenu, new Color(36, 87, 152));
        ChangeColor(lineMenu1, new Color(36, 87, 152));
    }//GEN-LAST:event_iMenuMouseExited

    private void iMobilesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMobilesMouseEntered
        ChangeColor(lineMobiles, new Color(8, 177, 150));
        ChangeColor(lineMobiles2, new Color(8, 177, 150));
    }//GEN-LAST:event_iMobilesMouseEntered

    private void iMobilesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMobilesMouseClicked
        mobilesPanel.setBackground(new Color(36, 87, 152));
        menuPanel.setBackground(new Color(10, 36, 101));
        mailPanel.setBackground(new Color(10, 36, 101));
        newsPanel.setBackground(new Color(10, 36, 101));
        shopPanel.setBackground(new Color(10, 36, 101));
        mobilesPanel2.setBackground(new Color(36, 87, 152));
        menuPanel1.setBackground(new Color(10, 36, 101));
        mailPanel1.setBackground(new Color(10, 36, 101));
        newsPanel2.setBackground(new Color(10, 36, 101));
        shopPanel1.setBackground(new Color(10, 36, 101));

    }//GEN-LAST:event_iMobilesMouseClicked

    private void iMobilesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMobilesMouseExited
        ChangeColor(lineMobiles, new Color(36, 87, 152));
        ChangeColor(lineMobiles2, new Color(36, 87, 152));
    }//GEN-LAST:event_iMobilesMouseExited

    private void iNewsMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iNewsMouseEntered
        ChangeColor(lineNews, new Color(254, 215, 0));
        ChangeColor(lineNews2, new Color(254, 215, 0));
    }//GEN-LAST:event_iNewsMouseEntered

    private void iNewsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iNewsMouseClicked
        mobilesPanel.setBackground(new Color(10, 36, 101));
        menuPanel.setBackground(new Color(10, 36, 101));
        mailPanel.setBackground(new Color(10, 36, 101));
        newsPanel.setBackground(new Color(36, 87, 152));
        shopPanel.setBackground(new Color(10, 36, 101));

        mobilesPanel2.setBackground(new Color(10, 36, 101));
        menuPanel1.setBackground(new Color(10, 36, 101));
        mailPanel1.setBackground(new Color(10, 36, 101));
        newsPanel2.setBackground(new Color(36, 87, 152));
        shopPanel1.setBackground(new Color(10, 36, 101));

    }//GEN-LAST:event_iNewsMouseClicked

    private void iNewsMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iNewsMouseExited
        ChangeColor(lineNews, new Color(36, 87, 152));
        ChangeColor(lineNews2, new Color(36, 87, 152));
    }//GEN-LAST:event_iNewsMouseExited

    private void iMailMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMailMouseEntered
        ChangeColor(lineMail, new Color(255, 255, 255));
        ChangeColor(lineMail2, new Color(255, 255, 255));
    }//GEN-LAST:event_iMailMouseEntered

    private void iMailMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMailMouseClicked
        mobilesPanel.setBackground(new Color(10, 36, 101));
        menuPanel.setBackground(new Color(10, 36, 101));
        mailPanel.setBackground(new Color(36, 87, 152));
        newsPanel.setBackground(new Color(10, 36, 101));
        shopPanel.setBackground(new Color(10, 36, 101));

        mobilesPanel2.setBackground(new Color(10, 36, 101));
        menuPanel1.setBackground(new Color(10, 36, 101));
        mailPanel1.setBackground(new Color(36, 87, 152));
        newsPanel2.setBackground(new Color(10, 36, 101));
        shopPanel1.setBackground(new Color(10, 36, 101));
    }//GEN-LAST:event_iMailMouseClicked

    private void iMailMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMailMouseExited
        ChangeColor(lineMail, new Color(36, 87, 152));
        ChangeColor(lineMail2, new Color(36, 87, 152));
    }//GEN-LAST:event_iMailMouseExited

    private void iShopMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iShopMouseEntered
        ChangeColor(lineShop, new Color(0, 255, 255));
        ChangeColor(lineShop2, new Color(0, 255, 255));
    }//GEN-LAST:event_iShopMouseEntered

    private void iShopMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iShopMouseClicked
        mobilesPanel.setBackground(new Color(10, 36, 101));
        menuPanel.setBackground(new Color(10, 36, 101));
        mailPanel.setBackground(new Color(10, 36, 101));
        newsPanel.setBackground(new Color(10, 36, 101));
        shopPanel.setBackground(new Color(36, 87, 152));

        mobilesPanel2.setBackground(new Color(10, 36, 101));
        menuPanel1.setBackground(new Color(10, 36, 101));
        mailPanel1.setBackground(new Color(10, 36, 101));
        newsPanel2.setBackground(new Color(10, 36, 101));
        shopPanel1.setBackground(new Color(36, 87, 152));
    }//GEN-LAST:event_iShopMouseClicked

    private void iShopMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iShopMouseExited
        ChangeColor(lineShop, new Color(36, 87, 152));
        ChangeColor(lineShop2, new Color(36, 87, 152));
    }//GEN-LAST:event_iShopMouseExited

    private void iNews1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iNews1MouseExited
        ChangeColor(lineNews, new Color(36, 87, 152));
        ChangeColor(lineNews2, new Color(36, 87, 152));
    }//GEN-LAST:event_iNews1MouseExited

    private void iNews1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iNews1MouseEntered
        ChangeColor(lineNews, new Color(254, 215, 0));
        ChangeColor(lineNews2, new Color(254, 215, 0));
    }//GEN-LAST:event_iNews1MouseEntered

    private void iNews1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iNews1MouseClicked
        mobilesPanel.setBackground(new Color(10, 36, 101));
        menuPanel.setBackground(new Color(10, 36, 101));
        mailPanel.setBackground(new Color(10, 36, 101));
        newsPanel.setBackground(new Color(36, 87, 152));
        shopPanel.setBackground(new Color(10, 36, 101));

        mobilesPanel2.setBackground(new Color(10, 36, 101));
        menuPanel1.setBackground(new Color(10, 36, 101));
        mailPanel1.setBackground(new Color(10, 36, 101));
        newsPanel2.setBackground(new Color(36, 87, 152));
        shopPanel1.setBackground(new Color(10, 36, 101));
    }//GEN-LAST:event_iNews1MouseClicked

    private void iMobiles1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMobiles1MouseClicked
        mobilesPanel.setBackground(new Color(36, 87, 152));
        menuPanel.setBackground(new Color(10, 36, 101));
        mailPanel.setBackground(new Color(10, 36, 101));
        newsPanel.setBackground(new Color(10, 36, 101));
        shopPanel.setBackground(new Color(10, 36, 101));

        mobilesPanel2.setBackground(new Color(36, 87, 152));
        menuPanel1.setBackground(new Color(10, 36, 101));
        mailPanel1.setBackground(new Color(10, 36, 101));
        newsPanel2.setBackground(new Color(10, 36, 101));
        shopPanel1.setBackground(new Color(10, 36, 101));

    }//GEN-LAST:event_iMobiles1MouseClicked

    private void iMobiles1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMobiles1MouseEntered
        ChangeColor(lineMobiles, new Color(8, 177, 150));
        ChangeColor(lineMobiles2, new Color(8, 177, 150));
    }//GEN-LAST:event_iMobiles1MouseEntered

    private void iMobiles1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMobiles1MouseExited
        ChangeColor(lineMobiles, new Color(36, 87, 152));
        ChangeColor(lineMobiles2, new Color(36, 87, 152));
    }//GEN-LAST:event_iMobiles1MouseExited

    private void iMail1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMail1MouseClicked
        mobilesPanel.setBackground(new Color(10, 36, 101));
        menuPanel.setBackground(new Color(10, 36, 101));
        mailPanel.setBackground(new Color(36, 87, 152));
        newsPanel.setBackground(new Color(10, 36, 101));
        shopPanel.setBackground(new Color(10, 36, 101));

        mobilesPanel2.setBackground(new Color(10, 36, 101));
        menuPanel1.setBackground(new Color(10, 36, 101));
        mailPanel1.setBackground(new Color(36, 87, 152));
        newsPanel2.setBackground(new Color(10, 36, 101));
        shopPanel1.setBackground(new Color(10, 36, 101));
    }//GEN-LAST:event_iMail1MouseClicked

    private void iMail1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMail1MouseEntered
        ChangeColor(lineMail, new Color(255, 255, 255));
        ChangeColor(lineMail2, new Color(255, 255, 255));

    }//GEN-LAST:event_iMail1MouseEntered

    private void iMail1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMail1MouseExited
        ChangeColor(lineMail, new Color(36, 87, 152));
        ChangeColor(lineMail2, new Color(36, 87, 152));
    }//GEN-LAST:event_iMail1MouseExited

    private void iShop1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iShop1MouseClicked
        mobilesPanel.setBackground(new Color(10, 36, 101));
        menuPanel.setBackground(new Color(10, 36, 101));
        mailPanel.setBackground(new Color(10, 36, 101));
        newsPanel.setBackground(new Color(10, 36, 101));
        shopPanel.setBackground(new Color(36, 87, 152));

        mobilesPanel2.setBackground(new Color(10, 36, 101));
        menuPanel1.setBackground(new Color(10, 36, 101));
        mailPanel1.setBackground(new Color(10, 36, 101));
        newsPanel2.setBackground(new Color(10, 36, 101));
        shopPanel1.setBackground(new Color(36, 87, 152));
    }//GEN-LAST:event_iShop1MouseClicked

    private void iShop1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iShop1MouseEntered
        ChangeColor(lineShop, new Color(0, 255, 255));
        ChangeColor(lineShop2, new Color(0, 255, 255));
    }//GEN-LAST:event_iShop1MouseEntered

    private void iShop1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iShop1MouseExited
        ChangeColor(lineShop, new Color(36, 87, 152));
        ChangeColor(lineShop2, new Color(36, 87, 152));
    }//GEN-LAST:event_iShop1MouseExited

    private void iMenu1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMenu1MouseExited
        ChangeColor(lineMenu, new Color(36, 87, 152));
        ChangeColor(lineMenu1, new Color(36, 87, 152));

    }//GEN-LAST:event_iMenu1MouseExited

    private void iMenu1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMenu1MouseEntered
        ChangeColor(lineMenu, new Color(247, 78, 104));
        ChangeColor(lineMenu1, new Color(247, 78, 104));
    }//GEN-LAST:event_iMenu1MouseEntered

    private void iMenu1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMenu1MouseClicked
        mobilesPanel.setBackground(new Color(10, 36, 101));
        // menuPanel.setBackground(new Color(36, 87, 152));
        mailPanel.setBackground(new Color(10, 36, 101));
        newsPanel.setBackground(new Color(10, 36, 101));
        shopPanel.setBackground(new Color(10, 36, 101));

    }//GEN-LAST:event_iMenu1MouseClicked

    private void iMenuMouseEntered(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


    private void outerPanel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_outerPanel2MouseClicked

        String name = mobileNameLabel2.getText();
        new MobileDetails(name).setVisible(true);
        setVisible(false);
    }//GEN-LAST:event_outerPanel2MouseClicked

    private void jPanel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel6MouseClicked
        ChangeColor(lineMenu1, new Color(255, 21, 110));

        String MobileName = searchTextField.getText();
        if (MobileName.length() > 0) {
            new MobileDetails(MobileName).setVisible(true);
        }
        setVisible(false);
    }//GEN-LAST:event_jPanel6MouseClicked

    private void jPanel6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel6MouseEntered
        ChangeColor(jPanel6, new Color(255, 0, 153));
    }//GEN-LAST:event_jPanel6MouseEntered

    private void jPanel6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel6MouseExited
        ChangeColor(jPanel6, new Color(255, 0, 255));
    }//GEN-LAST:event_jPanel6MouseExited

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Home().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTabbedPane DashboardTabbedPane;
    private javax.swing.JPanel dashBoardView;
    private javax.swing.JPanel header;
    private javax.swing.JLabel iMail;
    private javax.swing.JLabel iMail1;
    private javax.swing.JLabel iMenu;
    private javax.swing.JLabel iMenu1;
    private javax.swing.JLabel iMobiles;
    private javax.swing.JLabel iMobiles1;
    private javax.swing.JLabel iNews;
    private javax.swing.JLabel iNews1;
    private javax.swing.JLabel iShop;
    private javax.swing.JLabel iShop1;
    private javax.swing.JPanel innerPanel1;
    private javax.swing.JPanel innerPanel10;
    private javax.swing.JPanel innerPanel11;
    private javax.swing.JPanel innerPanel12;
    private javax.swing.JPanel innerPanel13;
    private javax.swing.JPanel innerPanel15;
    private javax.swing.JPanel innerPanel17;
    private javax.swing.JPanel innerPanel18;
    private javax.swing.JPanel innerPanel19;
    private javax.swing.JPanel innerPanel2;
    private javax.swing.JPanel innerPanel20;
    private javax.swing.JPanel innerPanel21;
    private javax.swing.JPanel innerPanel3;
    private javax.swing.JPanel innerPanel4;
    private javax.swing.JPanel innerPanel5;
    private javax.swing.JPanel innerPanel6;
    private javax.swing.JPanel innerPanel8;
    private javax.swing.JPanel innerPanel9;
    private javax.swing.JPanel items;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JPanel lineMail;
    private javax.swing.JPanel lineMail2;
    private javax.swing.JPanel lineMenu;
    private javax.swing.JPanel lineMenu1;
    private javax.swing.JPanel lineMobiles;
    private javax.swing.JPanel lineMobiles2;
    private javax.swing.JPanel lineNews;
    private javax.swing.JPanel lineNews2;
    private javax.swing.JPanel lineShop;
    private javax.swing.JPanel lineShop2;
    private javax.swing.JPanel mailPanel;
    private javax.swing.JPanel mailPanel1;
    private javax.swing.JPanel menu;
    private javax.swing.JPanel menuHide;
    private javax.swing.JPanel menuIcons;
    private javax.swing.JPanel menuPanel;
    private javax.swing.JPanel menuPanel1;
    private javax.swing.JLabel mobileNameLabel1;
    private javax.swing.JLabel mobileNameLabel10;
    private javax.swing.JLabel mobileNameLabel11;
    private javax.swing.JLabel mobileNameLabel12;
    private javax.swing.JLabel mobileNameLabel13;
    private javax.swing.JLabel mobileNameLabel15;
    private javax.swing.JLabel mobileNameLabel17;
    private javax.swing.JLabel mobileNameLabel18;
    private javax.swing.JLabel mobileNameLabel19;
    private javax.swing.JLabel mobileNameLabel2;
    private javax.swing.JLabel mobileNameLabel20;
    private javax.swing.JLabel mobileNameLabel21;
    private javax.swing.JLabel mobileNameLabel3;
    private javax.swing.JLabel mobileNameLabel4;
    private javax.swing.JLabel mobileNameLabel5;
    private javax.swing.JLabel mobileNameLabel6;
    private javax.swing.JLabel mobileNameLabel8;
    private javax.swing.JLabel mobileNameLabel9;
    private javax.swing.JLabel mobilePriceLabel1;
    private javax.swing.JLabel mobilePriceLabel10;
    private javax.swing.JLabel mobilePriceLabel11;
    private javax.swing.JLabel mobilePriceLabel12;
    private javax.swing.JLabel mobilePriceLabel13;
    private javax.swing.JLabel mobilePriceLabel15;
    private javax.swing.JLabel mobilePriceLabel17;
    private javax.swing.JLabel mobilePriceLabel18;
    private javax.swing.JLabel mobilePriceLabel19;
    private javax.swing.JLabel mobilePriceLabel2;
    private javax.swing.JLabel mobilePriceLabel20;
    private javax.swing.JLabel mobilePriceLabel21;
    private javax.swing.JLabel mobilePriceLabel3;
    private javax.swing.JLabel mobilePriceLabel4;
    private javax.swing.JLabel mobilePriceLabel5;
    private javax.swing.JLabel mobilePriceLabel6;
    private javax.swing.JLabel mobilePriceLabel8;
    private javax.swing.JLabel mobilePriceLabel9;
    private javax.swing.JPanel mobilesPanel;
    private javax.swing.JPanel mobilesPanel2;
    private javax.swing.JPanel newsPanel;
    private javax.swing.JPanel newsPanel2;
    private javax.swing.JPanel outerPanel1;
    private javax.swing.JPanel outerPanel10;
    private javax.swing.JPanel outerPanel11;
    private javax.swing.JPanel outerPanel12;
    private javax.swing.JPanel outerPanel13;
    private javax.swing.JPanel outerPanel15;
    private javax.swing.JPanel outerPanel17;
    private javax.swing.JPanel outerPanel18;
    private javax.swing.JPanel outerPanel19;
    private javax.swing.JPanel outerPanel2;
    private javax.swing.JPanel outerPanel20;
    private javax.swing.JPanel outerPanel21;
    private javax.swing.JPanel outerPanel3;
    private javax.swing.JPanel outerPanel4;
    private javax.swing.JPanel outerPanel5;
    private javax.swing.JPanel outerPanel6;
    private javax.swing.JPanel outerPanel8;
    private javax.swing.JPanel outerPanel9;
    private javax.swing.JLabel picLabel1;
    private javax.swing.JLabel picLabel10;
    private javax.swing.JLabel picLabel11;
    private javax.swing.JLabel picLabel12;
    private javax.swing.JLabel picLabel13;
    private javax.swing.JLabel picLabel15;
    private javax.swing.JLabel picLabel17;
    private javax.swing.JLabel picLabel18;
    private javax.swing.JLabel picLabel19;
    private javax.swing.JLabel picLabel2;
    private javax.swing.JLabel picLabel20;
    private javax.swing.JLabel picLabel21;
    private javax.swing.JLabel picLabel3;
    private javax.swing.JLabel picLabel4;
    private javax.swing.JLabel picLabel5;
    private javax.swing.JLabel picLabel6;
    private javax.swing.JLabel picLabel8;
    private javax.swing.JLabel picLabel9;
    private javax.swing.JLabel searchButton;
    private javax.swing.JTextField searchTextField;
    private javax.swing.JPanel shopPanel;
    private javax.swing.JPanel shopPanel1;
    // End of variables declaration//GEN-END:variables

}
