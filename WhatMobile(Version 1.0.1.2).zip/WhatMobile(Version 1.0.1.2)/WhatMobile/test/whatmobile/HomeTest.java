
package whatmobile;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JPanel;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


public class HomeTest {
    
    public HomeTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    
    @Test
    public void testChangeColor() {
        System.out.println("ChangeColor");
        JPanel hover = null;
        Color rand = null;
        Home instance = new Home();
        instance.ChangeColor(hover, rand);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of changeimage method, of class Home.
     */
    @Test
    public void testChangeimage() {
        System.out.println("changeimage");
        JLabel button = null;
        String resourcheimg = "";
        Home instance = new Home();
        instance.changeimage(button, resourcheimg);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    
    @Test
    public void testHideshow() {
        System.out.println("hideshow");
        JPanel menusHide = null;
        boolean dashBoardView = false;
        JLabel button = null;
        Home instance = new Home();
        instance.hideshow(menusHide, dashBoardView, button);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class Home.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Home.main(args);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
