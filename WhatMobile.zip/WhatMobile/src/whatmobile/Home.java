
package whatmobile;

import java.awt.*;
import javax.swing.*;

public class Home extends javax.swing.JFrame {

    boolean a = true;
    public Home() {
        initComponents();
    }

    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        header = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        CloseButton = new javax.swing.JPanel();
        closeLabel = new javax.swing.JLabel();
        minimizeButton = new javax.swing.JPanel();
        minimizeLabel = new javax.swing.JLabel();
        buttonMaximum = new javax.swing.JPanel();
        maxmimumLabel = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        menu = new javax.swing.JPanel();
        menuIcons = new javax.swing.JPanel();
        lineMenu = new javax.swing.JPanel();
        menuPanel = new javax.swing.JPanel();
        iMenu = new javax.swing.JLabel();
        lineMobiles = new javax.swing.JPanel();
        mobilesPanel = new javax.swing.JPanel();
        iMobiles = new javax.swing.JLabel();
        lineNews = new javax.swing.JPanel();
        newsPanel = new javax.swing.JPanel();
        iNews = new javax.swing.JLabel();
        lineMail = new javax.swing.JPanel();
        mailPanel = new javax.swing.JPanel();
        iMail = new javax.swing.JLabel();
        lineShop = new javax.swing.JPanel();
        shopPanel = new javax.swing.JPanel();
        iShop = new javax.swing.JLabel();
        menuHide = new javax.swing.JPanel();
        mailPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        lineNews1 = new javax.swing.JPanel();
        lineMail1 = new javax.swing.JPanel();
        lineShop1 = new javax.swing.JPanel();
        mailPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        shopPanel1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        newsPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        dashBoardView = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(800, 500));

        header.setBackground(new java.awt.Color(36, 87, 152));
        header.setLayout(new java.awt.BorderLayout());

        jPanel5.setBackground(new java.awt.Color(36, 87, 152));
        jPanel5.setMinimumSize(new java.awt.Dimension(170, 40));
        jPanel5.setPreferredSize(new java.awt.Dimension(170, 40));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        CloseButton.setBackground(new java.awt.Color(36, 87, 152));
        CloseButton.setLayout(new java.awt.BorderLayout());

        closeLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/icons8_multiply_48.png"))); // NOI18N
        closeLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                closeLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                closeLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                closeLabelMouseExited(evt);
            }
        });
        CloseButton.add(closeLabel, java.awt.BorderLayout.CENTER);

        jPanel5.add(CloseButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 0, 50, 50));

        minimizeButton.setBackground(new java.awt.Color(36, 87, 152));
        minimizeButton.setLayout(new java.awt.BorderLayout());

        minimizeLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/icons8_subtract_48.png"))); // NOI18N
        minimizeLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                minimizeLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                minimizeLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                minimizeLabelMouseExited(evt);
            }
        });
        minimizeButton.add(minimizeLabel, java.awt.BorderLayout.CENTER);

        jPanel5.add(minimizeButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 50, 50));

        buttonMaximum.setBackground(new java.awt.Color(36, 87, 152));
        buttonMaximum.setLayout(new java.awt.BorderLayout());

        maxmimumLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/icons8_full_screen_48.png"))); // NOI18N
        maxmimumLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                maxmimumLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                maxmimumLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                maxmimumLabelMouseExited(evt);
            }
        });
        buttonMaximum.add(maxmimumLabel, java.awt.BorderLayout.CENTER);

        jPanel5.add(buttonMaximum, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 0, 50, 50));

        header.add(jPanel5, java.awt.BorderLayout.LINE_END);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/11070823_798808190167734_5912407124608451387_n.png"))); // NOI18N
        header.add(jLabel1, java.awt.BorderLayout.CENTER);

        getContentPane().add(header, java.awt.BorderLayout.PAGE_START);

        menu.setBackground(new java.awt.Color(36, 87, 152));
        menu.setPreferredSize(new java.awt.Dimension(270, 400));
        menu.setLayout(new java.awt.BorderLayout());

        menuIcons.setBackground(new java.awt.Color(10, 36, 101));
        menuIcons.setPreferredSize(new java.awt.Dimension(60, 400));
        menuIcons.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lineMenu.setBackground(new java.awt.Color(10, 36, 101));
        lineMenu.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineMenuLayout = new javax.swing.GroupLayout(lineMenu);
        lineMenu.setLayout(lineMenuLayout);
        lineMenuLayout.setHorizontalGroup(
            lineMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        lineMenuLayout.setVerticalGroup(
            lineMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuIcons.add(lineMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 60, 5));

        menuPanel.setBackground(new java.awt.Color(10, 36, 101));
        menuPanel.setLayout(new java.awt.BorderLayout());

        iMenu.setBackground(new java.awt.Color(10, 36, 101));
        iMenu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/icons8_menu_48.png"))); // NOI18N
        iMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iMenuMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iMenuMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iMenuMouseExited(evt);
            }
        });
        menuPanel.add(iMenu, java.awt.BorderLayout.CENTER);

        menuIcons.add(menuPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 5, 60, 60));

        lineMobiles.setBackground(new java.awt.Color(10, 36, 101));
        lineMobiles.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineMobilesLayout = new javax.swing.GroupLayout(lineMobiles);
        lineMobiles.setLayout(lineMobilesLayout);
        lineMobilesLayout.setHorizontalGroup(
            lineMobilesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        lineMobilesLayout.setVerticalGroup(
            lineMobilesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuIcons.add(lineMobiles, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 65, 60, 5));

        mobilesPanel.setBackground(new java.awt.Color(10, 36, 101));
        mobilesPanel.setLayout(new java.awt.BorderLayout());

        iMobiles.setBackground(new java.awt.Color(10, 36, 101));
        iMobiles.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iMobiles.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/icons8_mobile_48.png"))); // NOI18N
        iMobiles.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iMobilesMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iMobilesMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iMobilesMouseExited(evt);
            }
        });
        mobilesPanel.add(iMobiles, java.awt.BorderLayout.CENTER);

        menuIcons.add(mobilesPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 60, 60));

        lineNews.setBackground(new java.awt.Color(10, 36, 101));
        lineNews.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineNewsLayout = new javax.swing.GroupLayout(lineNews);
        lineNews.setLayout(lineNewsLayout);
        lineNewsLayout.setHorizontalGroup(
            lineNewsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        lineNewsLayout.setVerticalGroup(
            lineNewsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuIcons.add(lineNews, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 60, 5));

        newsPanel.setBackground(new java.awt.Color(10, 36, 101));
        newsPanel.setLayout(new java.awt.BorderLayout());

        iNews.setBackground(new java.awt.Color(10, 36, 101));
        iNews.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iNews.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/icons8_news_48.png"))); // NOI18N
        iNews.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iNewsMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iNewsMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iNewsMouseExited(evt);
            }
        });
        newsPanel.add(iNews, java.awt.BorderLayout.CENTER);

        menuIcons.add(newsPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 135, 60, 60));

        lineMail.setBackground(new java.awt.Color(10, 36, 101));
        lineMail.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineMailLayout = new javax.swing.GroupLayout(lineMail);
        lineMail.setLayout(lineMailLayout);
        lineMailLayout.setHorizontalGroup(
            lineMailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        lineMailLayout.setVerticalGroup(
            lineMailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuIcons.add(lineMail, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 195, 60, 5));

        mailPanel.setBackground(new java.awt.Color(10, 36, 101));
        mailPanel.setLayout(new java.awt.BorderLayout());

        iMail.setBackground(new java.awt.Color(10, 36, 101));
        iMail.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iMail.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/icons8_mailbox_48.png"))); // NOI18N
        iMail.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iMailMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iMailMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iMailMouseExited(evt);
            }
        });
        mailPanel.add(iMail, java.awt.BorderLayout.CENTER);

        menuIcons.add(mailPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 60, 60));

        lineShop.setBackground(new java.awt.Color(10, 36, 101));
        lineShop.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineShopLayout = new javax.swing.GroupLayout(lineShop);
        lineShop.setLayout(lineShopLayout);
        lineShopLayout.setHorizontalGroup(
            lineShopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        lineShopLayout.setVerticalGroup(
            lineShopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuIcons.add(lineShop, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 260, 60, 5));

        shopPanel.setBackground(new java.awt.Color(10, 36, 101));
        shopPanel.setLayout(new java.awt.BorderLayout());

        iShop.setBackground(new java.awt.Color(10, 36, 101));
        iShop.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iShop.setIcon(new javax.swing.ImageIcon(getClass().getResource("/whatmobile/icons/icons8_shop_48.png"))); // NOI18N
        iShop.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iShopMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iShopMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                iShopMouseExited(evt);
            }
        });
        shopPanel.add(iShop, java.awt.BorderLayout.CENTER);

        menuIcons.add(shopPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 265, 60, 60));

        menu.add(menuIcons, java.awt.BorderLayout.LINE_START);

        menuHide.setBackground(new java.awt.Color(36, 87, 152));
        menuHide.setRequestFocusEnabled(false);
        menuHide.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        mailPanel1.setBackground(new java.awt.Color(10, 36, 101));
        mailPanel1.setLayout(new java.awt.BorderLayout());

        jLabel4.setFont(new java.awt.Font("Yu Gothic UI Light", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Contact");
        mailPanel1.add(jLabel4, java.awt.BorderLayout.CENTER);

        menuHide.add(mailPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 210, 60));

        lineNews1.setBackground(new java.awt.Color(10, 36, 101));
        lineNews1.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineNews1Layout = new javax.swing.GroupLayout(lineNews1);
        lineNews1.setLayout(lineNews1Layout);
        lineNews1Layout.setHorizontalGroup(
            lineNews1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 210, Short.MAX_VALUE)
        );
        lineNews1Layout.setVerticalGroup(
            lineNews1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuHide.add(lineNews1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 210, 5));

        lineMail1.setBackground(new java.awt.Color(10, 36, 101));
        lineMail1.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineMail1Layout = new javax.swing.GroupLayout(lineMail1);
        lineMail1.setLayout(lineMail1Layout);
        lineMail1Layout.setHorizontalGroup(
            lineMail1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 210, Short.MAX_VALUE)
        );
        lineMail1Layout.setVerticalGroup(
            lineMail1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuHide.add(lineMail1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 195, 210, 5));

        lineShop1.setBackground(new java.awt.Color(10, 36, 101));
        lineShop1.setPreferredSize(new java.awt.Dimension(60, 5));

        javax.swing.GroupLayout lineShop1Layout = new javax.swing.GroupLayout(lineShop1);
        lineShop1.setLayout(lineShop1Layout);
        lineShop1Layout.setHorizontalGroup(
            lineShop1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 210, Short.MAX_VALUE)
        );
        lineShop1Layout.setVerticalGroup(
            lineShop1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        menuHide.add(lineShop1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 260, 210, 5));

        mailPanel2.setBackground(new java.awt.Color(10, 36, 101));
        mailPanel2.setLayout(new java.awt.BorderLayout());

        jLabel2.setFont(new java.awt.Font("Yu Gothic UI Light", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Mobiles");
        mailPanel2.add(jLabel2, java.awt.BorderLayout.CENTER);

        menuHide.add(mailPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 210, 60));

        shopPanel1.setBackground(new java.awt.Color(10, 36, 101));
        shopPanel1.setLayout(new java.awt.BorderLayout());

        jLabel5.setFont(new java.awt.Font("Yu Gothic UI Light", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Shops");
        shopPanel1.add(jLabel5, java.awt.BorderLayout.CENTER);

        menuHide.add(shopPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 265, 210, 60));

        newsPanel1.setBackground(new java.awt.Color(10, 36, 101));
        newsPanel1.setLayout(new java.awt.BorderLayout());

        jLabel3.setFont(new java.awt.Font("Yu Gothic UI Light", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("News");
        newsPanel1.add(jLabel3, java.awt.BorderLayout.CENTER);

        menuHide.add(newsPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 135, 210, 60));

        menu.add(menuHide, java.awt.BorderLayout.CENTER);

        getContentPane().add(menu, java.awt.BorderLayout.LINE_START);

        dashBoardView.setBackground(new java.awt.Color(153, 102, 255));

        javax.swing.GroupLayout dashBoardViewLayout = new javax.swing.GroupLayout(dashBoardView);
        dashBoardView.setLayout(dashBoardViewLayout);
        dashBoardViewLayout.setHorizontalGroup(
            dashBoardViewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 983, Short.MAX_VALUE)
        );
        dashBoardViewLayout.setVerticalGroup(
            dashBoardViewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 428, Short.MAX_VALUE)
        );

        getContentPane().add(dashBoardView, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 1253, 614);
    }// </editor-fold>//GEN-END:initComponents

    public void ChangeColor(JPanel hover, Color rand){
        hover.setBackground(rand);
    }
    public void hideshow(JPanel menuHide,boolean dashboard){
        if (dashboard == true) {
            menuHide.setPreferredSize(new Dimension(60, menuHide.getHeight()));
        }
        else{
            menuHide.setPreferredSize(new Dimension(270, menuHide.getHeight()));
        }
    }
        
    private void closeLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeLabelMouseClicked
        System.exit(0);
    }//GEN-LAST:event_closeLabelMouseClicked

    private void closeLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeLabelMouseEntered
        ChangeColor(CloseButton, new Color(216, 59, 1));
    }//GEN-LAST:event_closeLabelMouseEntered

    private void closeLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeLabelMouseExited
        ChangeColor(CloseButton, new Color(181, 64, 30));
    }//GEN-LAST:event_closeLabelMouseExited

    private void maxmimumLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_maxmimumLabelMouseEntered
        ChangeColor(buttonMaximum, new Color(0, 0, 255));
    }//GEN-LAST:event_maxmimumLabelMouseEntered

    private void maxmimumLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_maxmimumLabelMouseClicked
        if(this.getExtendedState()!= Home.MAXIMIZED_BOTH){
            this.setExtendedState(Home.MAXIMIZED_BOTH);
        }
        else{
            this.setExtendedState(Home.NORMAL);
        }
    }//GEN-LAST:event_maxmimumLabelMouseClicked

    private void maxmimumLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_maxmimumLabelMouseExited
        ChangeColor(buttonMaximum, new Color(36, 87, 152));
    }//GEN-LAST:event_maxmimumLabelMouseExited

    private void minimizeLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimizeLabelMouseEntered
        ChangeColor(buttonMaximum, new Color(0, 0, 255));
    }//GEN-LAST:event_minimizeLabelMouseEntered

    private void minimizeLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimizeLabelMouseClicked
        
    }//GEN-LAST:event_minimizeLabelMouseClicked

    private void minimizeLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimizeLabelMouseExited
        ChangeColor(buttonMaximum, new Color(36, 87, 152));
    }//GEN-LAST:event_minimizeLabelMouseExited

    private void iMenuMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMenuMouseEntered
        ChangeColor(lineMenu, new Color(247,78,104));
    }//GEN-LAST:event_iMenuMouseEntered

    private void iMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMenuMouseClicked
        mobilesPanel.setBackground(new Color(10, 36, 101));
        menuPanel.setBackground(new Color(36, 87, 152));
        mailPanel.setBackground(new Color(10, 36, 101));
        newsPanel.setBackground(new Color(10, 36, 101));
        shopPanel.setBackground(new Color(10, 36, 101));
        if (a==true) {
            hideshow(menu, a);
            SwingUtilities.updateComponentTreeUI(this);
            a=false;
        }
        else
        hideshow(menu,a);
        SwingUtilities.updateComponentTreeUI(this);
        a=true;
      
    }//GEN-LAST:event_iMenuMouseClicked

    private void iMenuMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMenuMouseExited
        ChangeColor(lineMenu, new Color(36, 87, 152));
    }//GEN-LAST:event_iMenuMouseExited

    private void iMobilesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMobilesMouseEntered
        ChangeColor(lineMobiles, new Color(8,177,150));
    }//GEN-LAST:event_iMobilesMouseEntered

    private void iMobilesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMobilesMouseClicked
        mobilesPanel.setBackground(new Color(36, 87, 152));
        menuPanel.setBackground(new Color(10, 36, 101));
        mailPanel.setBackground(new Color(10, 36, 101));
        newsPanel.setBackground(new Color(10, 36, 101));
        shopPanel.setBackground(new Color(10, 36, 101));
    }//GEN-LAST:event_iMobilesMouseClicked

    private void iMobilesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMobilesMouseExited
        ChangeColor(lineMobiles, new Color(36, 87, 152));
    }//GEN-LAST:event_iMobilesMouseExited

    private void iNewsMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iNewsMouseEntered
        ChangeColor(lineNews, new Color(254, 215, 0));
    }//GEN-LAST:event_iNewsMouseEntered

    private void iNewsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iNewsMouseClicked
        mobilesPanel.setBackground(new Color(10, 36, 101));
        menuPanel.setBackground(new Color(10, 36, 101));
        mailPanel.setBackground(new Color(10, 36, 101));
        newsPanel.setBackground(new Color(36, 87, 152));
        shopPanel.setBackground(new Color(10, 36, 101));
    }//GEN-LAST:event_iNewsMouseClicked

    private void iNewsMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iNewsMouseExited
        ChangeColor(lineNews, new Color(36, 87, 152));
    }//GEN-LAST:event_iNewsMouseExited

    private void iMailMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMailMouseEntered
        ChangeColor(lineMail, new Color(255, 255, 255));
    }//GEN-LAST:event_iMailMouseEntered

    private void iMailMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMailMouseClicked
        mobilesPanel.setBackground(new Color(10, 36, 101));
        menuPanel.setBackground(new Color(10, 36, 101));
        mailPanel.setBackground(new Color(36, 87, 152));
        newsPanel.setBackground(new Color(10, 36, 101));
        shopPanel.setBackground(new Color(10, 36, 101));
    }//GEN-LAST:event_iMailMouseClicked

    private void iMailMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iMailMouseExited
        ChangeColor(lineMail, new Color(36, 87, 152));
    }//GEN-LAST:event_iMailMouseExited

    private void iShopMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iShopMouseEntered
        ChangeColor(lineShop, new Color(0, 255, 255));
    }//GEN-LAST:event_iShopMouseEntered

    private void iShopMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iShopMouseClicked
        mobilesPanel.setBackground(new Color(10, 36, 101));
        menuPanel.setBackground(new Color(10, 36, 101));
        mailPanel.setBackground(new Color(10, 36, 101));
        newsPanel.setBackground(new Color(10, 36, 101));
        shopPanel.setBackground(new Color(36, 87, 152));
    }//GEN-LAST:event_iShopMouseClicked

    private void iShopMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iShopMouseExited
        ChangeColor(lineShop, new Color(36, 87, 152));
    }//GEN-LAST:event_iShopMouseExited

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Home().setVisible(true);
                
            }
             /* public void openmenu()
              {
                  new Home().iMenuMouseEntered(true);
              }*/
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel CloseButton;
    private javax.swing.JPanel buttonMaximum;
    private javax.swing.JLabel closeLabel;
    private javax.swing.JPanel dashBoardView;
    private javax.swing.JPanel header;
    private javax.swing.JLabel iMail;
    private javax.swing.JLabel iMenu;
    private javax.swing.JLabel iMobiles;
    private javax.swing.JLabel iNews;
    private javax.swing.JLabel iShop;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel lineMail;
    private javax.swing.JPanel lineMail1;
    private javax.swing.JPanel lineMenu;
    private javax.swing.JPanel lineMobiles;
    private javax.swing.JPanel lineNews;
    private javax.swing.JPanel lineNews1;
    private javax.swing.JPanel lineShop;
    private javax.swing.JPanel lineShop1;
    private javax.swing.JPanel mailPanel;
    private javax.swing.JPanel mailPanel1;
    private javax.swing.JPanel mailPanel2;
    private javax.swing.JLabel maxmimumLabel;
    private javax.swing.JPanel menu;
    private javax.swing.JPanel menuHide;
    private javax.swing.JPanel menuIcons;
    private javax.swing.JPanel menuPanel;
    private javax.swing.JPanel minimizeButton;
    private javax.swing.JLabel minimizeLabel;
    private javax.swing.JPanel mobilesPanel;
    private javax.swing.JPanel newsPanel;
    private javax.swing.JPanel newsPanel1;
    private javax.swing.JPanel shopPanel;
    private javax.swing.JPanel shopPanel1;
    // End of variables declaration//GEN-END:variables

    private void iMenuMouseEntered(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
